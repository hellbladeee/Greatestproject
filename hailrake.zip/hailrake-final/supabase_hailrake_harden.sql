-- Усиление: пароли учителей больше не читаются напрямую через anon key.
-- Вместо policy "teachers readable" (select true) — RPC-функция, которая
-- сверяет логин/пароль на сервере и возвращает только логин при совпадении.
-- Выполнить в Supabase Dashboard -> SQL Editor -> New query -> Run

drop policy if exists "teachers readable" on teachers;
-- select-политики на teachers больше нет вообще — таблица недоступна для чтения
-- напрямую через anon key, только через функцию ниже.

create or replace function verify_teacher(p_login text, p_password text)
returns table(login text, name text)
language sql
security definer
set search_path = public
as $$
  select t.login, t.name
  from teachers t
  where t.login = p_login and t.password = p_password;
$$;

grant execute on function verify_teacher(text, text) to anon, authenticated;
