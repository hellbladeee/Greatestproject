-- Hailrake AI v2: короткий код класса вместо логина учителя, логин/пароль для учеников.
-- Выполнить в SQL Editor ПОСЛЕ supabase_hailrake.sql и supabase_hailrake_harden.sql

alter table teachers add column if not exists class_code text unique;
update teachers set class_code = 'DEMO01' where login = 'teacher1' and class_code is null;

alter table students add column if not exists class_code text;
alter table students add column if not exists login text unique;
alter table students add column if not exists password text;

create index if not exists idx_students_class_code on students(class_code);

-- verify_teacher теперь возвращает и код класса — учителю нужно его показать ученикам.
-- DROP обязателен: Postgres не позволяет менять набор колонок результата через CREATE OR REPLACE.
drop function if exists verify_teacher(text, text);

create or replace function verify_teacher(p_login text, p_password text)
returns table(login text, name text, class_code text)
language sql
security definer
set search_path = public
as $$
  select t.login, t.name, t.class_code
  from teachers t
  where t.login = p_login and t.password = p_password;
$$;

grant execute on function verify_teacher(text, text) to anon, authenticated;

-- Вход ученика по логину/паролю, которые создал учитель.
create or replace function verify_student(p_login text, p_password text)
returns table(id text, name text, class_code text)
language sql
security definer
set search_path = public
as $$
  select s.id, s.name, s.class_code
  from students s
  where s.login = p_login and s.password = p_password;
$$;

grant execute on function verify_student(text, text) to anon, authenticated;
