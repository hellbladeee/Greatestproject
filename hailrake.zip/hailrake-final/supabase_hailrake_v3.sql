-- Hailrake AI v3: темы и задания, созданные учителем, теперь реально видны ученикам —
-- раньше сохранялись только в localStorage браузера учителя.
-- Выполнить в SQL Editor ПОСЛЕ v2.

alter table teachers add column if not exists custom_topics jsonb not null default '[]'::jsonb;
alter table teachers add column if not exists custom_items jsonb not null default '[]'::jsonb;

-- Прямого доступа на update к teachers как не было, так и нет — запись контента класса
-- идёт только через save_class_content ниже (security definer, работает в обход RLS).

-- Публичное чтение контента класса по коду — нужно ученикам, у которых нет входа в teachers напрямую.
create or replace function get_class_content(p_class_code text)
returns table(custom_topics jsonb, custom_items jsonb)
language sql
security definer
set search_path = public
as $$
  select t.custom_topics, t.custom_items
  from teachers t
  where t.class_code = p_class_code;
$$;

grant execute on function get_class_content(text) to anon, authenticated;

create or replace function save_class_content(p_class_code text, p_topics jsonb, p_items jsonb)
returns void
language sql
security definer
set search_path = public
as $$
  update teachers
  set custom_topics = p_topics, custom_items = p_items
  where class_code = p_class_code;
$$;

grant execute on function save_class_content(text, jsonb, jsonb) to anon, authenticated;
