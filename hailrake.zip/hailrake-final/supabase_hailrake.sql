-- Hailrake AI: реальные логины учителей и реальные ученики вместо фейкового cohort.
-- Выполнить в Supabase Dashboard -> SQL Editor -> New query -> Run
-- (тот же проект, что и Plastic School AI — таблицы не пересекаются по именам)

create table if not exists teachers (
  id uuid primary key default gen_random_uuid(),
  login text not null unique,
  password text not null,
  name text not null,
  created_at timestamptz not null default now()
);

create table if not exists students (
  id text primary key,               -- стабильный id, сгенерированный в браузере ученика
  teacher_login text references teachers(login) on delete set null,
  name text not null,
  grade int,
  region text,
  school text,
  subjects jsonb,
  goal text,
  target int,
  mastery jsonb,                     -- Record<topicId, 0..1>
  attempts_by_topic jsonb,
  correct_count int default 0,
  total_count int default 0,
  xp int default 0,
  updated_at timestamptz not null default now()
);

create index if not exists idx_students_teacher on students(teacher_login);

alter table teachers enable row level security;
alter table students enable row level security;

-- MVP школьного хакатона: простой открытый доступ через anon key (как и в Plastic School AI).
create policy "teachers readable" on teachers for select using (true);
create policy "students readable" on students for select using (true);
create policy "students upsertable" on students for insert with check (true);
create policy "students updatable" on students for update using (true);

-- Демо-учитель для быстрого входа жюри.
insert into teachers (login, password, name) values
  ('teacher1', 'demo123', 'Демо-учитель')
on conflict (login) do nothing;
