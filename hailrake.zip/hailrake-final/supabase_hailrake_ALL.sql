-- Hailrake AI — ПОЛНЫЙ скрипт (v1 + harden + v2 + v3 объединены).
-- Безопасно запускать даже повторно поверх уже частично применённых версий —
-- везде IF NOT EXISTS / DROP...IF EXISTS + CREATE, дублирования не будет.
-- Выполнить в Supabase Dashboard -> SQL Editor -> New query -> Run (одним запуском).

-- ==================== ТАБЛИЦЫ ====================

create table if not exists teachers (
  id uuid primary key default gen_random_uuid(),
  login text not null unique,
  password text not null,
  name text not null,
  created_at timestamptz not null default now()
);

create table if not exists students (
  id text primary key,
  name text not null,
  grade int,
  region text,
  school text,
  subjects jsonb,
  goal text,
  target int,
  mastery jsonb,
  attempts_by_topic jsonb,
  correct_count int default 0,
  total_count int default 0,
  xp int default 0,
  updated_at timestamptz not null default now()
);

-- Колонки, добавленные в последующих версиях (v2) — IF NOT EXISTS делает их безопасными
-- при любом порядке/повторе запуска.
alter table teachers add column if not exists class_code text unique;
alter table teachers add column if not exists custom_topics jsonb not null default '[]'::jsonb;
alter table teachers add column if not exists custom_items jsonb not null default '[]'::jsonb;

alter table students add column if not exists class_code text;
alter table students add column if not exists login text unique;
alter table students add column if not exists password text;

create index if not exists idx_students_class_code on students(class_code);

-- ==================== RLS ====================

alter table teachers enable row level security;
alter table students enable row level security;

-- Прямое чтение teachers закрыто полностью (пароли не должны читаться напрямую через anon key) —
-- весь доступ только через security definer функции ниже.
drop policy if exists "teachers readable" on teachers;

drop policy if exists "students readable" on students;
create policy "students readable" on students for select using (true);

drop policy if exists "students upsertable" on students;
create policy "students upsertable" on students for insert with check (true);

drop policy if exists "students updatable" on students;
create policy "students updatable" on students for update using (true);

drop policy if exists "students deletable" on students;
create policy "students deletable" on students for delete using (true);

-- ==================== ДЕМО-УЧИТЕЛЬ ====================

insert into teachers (login, password, name) values
  ('teacher1', 'demo123', 'Демо-учитель')
on conflict (login) do nothing;

update teachers set class_code = 'DEMO01' where login = 'teacher1' and class_code is null;

-- ==================== ФУНКЦИИ ====================

-- DROP обязателен перед пересозданием: Postgres не даёт менять набор колонок результата
-- через CREATE OR REPLACE, если функция уже существует с другой сигнатурой.
drop function if exists verify_teacher(text, text);

create function verify_teacher(p_login text, p_password text)
returns table(login text, name text, class_code text)
language sql
security definer
set search_path = public
as $$
  select t.login, t.name, t.class_code
  from teachers t
  where t.login = p_login and t.password = p_password;
$$;

grant execute on function verify_teacher(text, text) to anon, authenticated;

drop function if exists verify_student(text, text);

create function verify_student(p_login text, p_password text)
returns table(id text, name text, class_code text)
language sql
security definer
set search_path = public
as $$
  select s.id, s.name, s.class_code
  from students s
  where s.login = p_login and s.password = p_password;
$$;

grant execute on function verify_student(text, text) to anon, authenticated;

drop function if exists get_class_content(text);

create function get_class_content(p_class_code text)
returns table(custom_topics jsonb, custom_items jsonb)
language sql
security definer
set search_path = public
as $$
  select t.custom_topics, t.custom_items
  from teachers t
  where t.class_code = p_class_code;
$$;

grant execute on function get_class_content(text) to anon, authenticated;

drop function if exists save_class_content(text, jsonb, jsonb);

create function save_class_content(p_class_code text, p_topics jsonb, p_items jsonb)
returns void
language sql
security definer
set search_path = public
as $$
  update teachers
  set custom_topics = p_topics, custom_items = p_items
  where class_code = p_class_code;
$$;

grant execute on function save_class_content(text, jsonb, jsonb) to anon, authenticated;

-- ==================== ПРОВЕРКА ====================
-- После запуска этот select должен вернуть одну строку: teacher1 | Демо-учитель | DEMO01
select * from verify_teacher('teacher1', 'demo123');
