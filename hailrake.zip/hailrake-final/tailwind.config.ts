import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      keyframes: {
        up: { '0%': { opacity: '0', transform: 'translateY(8px)' }, '100%': { opacity: '1', transform: 'none' } },
        pop: { '0%': { opacity: '0', transform: 'scale(.85)' }, '100%': { opacity: '1', transform: 'scale(1)' } },
      },
      animation: { up: 'up .4s ease-out both', pop: 'pop .35s ease-out both' },
    },
  },
  plugins: [],
};
export default config;