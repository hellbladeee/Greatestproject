'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useLanguage } from '@/context/LanguageContext';
import { useStore } from '@/lib/state';
import { studentLogin } from '@/lib/sync';
import { Btn, Card, Shell, Title } from '@/components/ui';

const dict = {
  ru: {
    eyebrow: 'Вход ученика',
    title: 'Вход по логину',
    sub: 'Используйте логин и пароль, которые вам выдал учитель.',
    loginPlaceholder: 'Логин',
    passPlaceholder: 'Пароль',
    signIn: 'Войти →',
    wrong: 'Неверный логин или пароль.',
    or: 'Или начните заново без учителя →',
  },
  kz: {
    eyebrow: 'Оқушы кірісі',
    title: 'Логинмен кіру',
    sub: 'Мұғалім берген логин мен құпия сөзді пайдаланыңыз.',
    loginPlaceholder: 'Логин',
    passPlaceholder: 'Құпия сөз',
    signIn: 'Кіру →',
    wrong: 'Логин немесе құпия сөз қате.',
    or: 'Немесе мұғалімсіз бастаңыз →',
  },
  en: {
    eyebrow: 'Student login',
    title: 'Log in',
    sub: 'Use the login and password your teacher gave you.',
    loginPlaceholder: 'Login',
    passPlaceholder: 'Password',
    signIn: 'Sign in →',
    wrong: 'Incorrect login or password.',
    or: 'Or start fresh without a teacher →',
  },
};

export default function StudentLogin() {
  const r = useRouter();
  const { lang } = useLanguage();
  const t = dict[lang];
  const { saveProfile } = useStore();

  const [login, setLogin] = useState('');
  const [password, setPassword] = useState('');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErr('');
    setBusy(true);
    const result = await studentLogin(login, password);
    setBusy(false);
    if (!result) {
      setErr(t.wrong);
      return;
    }
    // Используем ТОТ ЖЕ id, что и в Supabase — дальнейшая синхронизация будет
    // обновлять эту же строку, а не создавать новую на каждом устройстве.
    saveProfile({
      id: result.id,
      name: result.name,
      grade: 11,
      region: '',
      school: '',
      subjects: ['math', 'physics'],
      goal: 'ЕНТ',
      target: 110,
      examDate: '2027-06-20',
      minutesPerDay: 45,
      teacherCode: result.class_code ?? undefined,
    });
    r.push('/onboarding');
  };

  return (
    <Shell>
      <div className="wrap max-w-md py-24">
        <Card className="p-8">
          <Title eyebrow={t.eyebrow} title={t.title} sub={t.sub} />
          <form onSubmit={submit} className="mt-6 space-y-4">
            <input
              type="text"
              placeholder={t.loginPlaceholder}
              value={login}
              onChange={(e) => setLogin(e.target.value)}
              className="w-full rounded-xl border border-[#1F2937] bg-[#0F1622] px-4 py-3 text-sm text-white focus:border-[#10B981] focus:outline-none"
            />
            <input
              type="password"
              placeholder={t.passPlaceholder}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full rounded-xl border border-[#1F2937] bg-[#0F1622] px-4 py-3 text-sm text-white focus:border-[#10B981] focus:outline-none"
            />
            {err && <p className="text-xs text-[#F43F5E]">{err}</p>}
            <Btn className="w-full" type="submit" disabled={busy}>{busy ? '…' : t.signIn}</Btn>
          </form>
          <button onClick={() => r.push('/onboarding')} className="mt-4 text-[12px] text-slate-500 hover:text-slate-300">
            {t.or}
          </button>
        </Card>
      </div>
    </Shell>
  );
}
