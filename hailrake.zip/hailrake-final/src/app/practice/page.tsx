'use client';
import { useRouter } from 'next/navigation';
import { useLanguage } from '@/context/LanguageContext';
import { useMemo, useState } from 'react';
import { TOPICS, type Item } from '@/lib/data';
import { localizeItem, localizeTopic } from '@/lib/content';
import { estimateTheta, forecast, itemsOf, pCorrect, pickPractice, relevantTopics } from '@/lib/engine';
import { useStore } from '@/lib/state';
import { Badge, Bar, Btn, Card, Shell, Stat, Title, cx } from '@/components/ui';

const LEN = 5;


const dict = {
  ru: {
    lang: 'ru',
    loading: 'Загрузка…',
    noProfileTitle: 'Профиль не создан',
    noProfileSub: 'Практикум подбирает задания под ваш уровень.',
    createProfile: 'Создать профиль',
    eyebrow: 'Практикум',
    selectModule: 'Выберите модуль',
    selectModuleSub: 'Сложность внутри модуля подбирается динамически: платформа держит вероятность успеха около 75% — это зона максимального роста.',
    new: 'новая',
    tasks: 'заданий',
    entWeight: 'вес ЕНТ',
    mastery: 'освоение',
    noTasks: 'Нет заданий',
    startSession: 'Начать сессию',
    sessionFinished: 'Сессия завершена',
    sessionResults: 'Итоги сессии',
    correct: 'Верно',
    topicMastery: 'Освоение темы',
    entScoreForecast: 'Прогноз ЕНТ',
    sessionGain: 'за сессию',
    moreSession: 'Ещё сессия',
    otherModule: 'Другой модуль',
    toDashboard: 'В кабинет',
    successChance: 'шанс успеха ≈',
    taskOf: 'задание',
    of: 'из',
    rightAnswers: 'верных',
    difficulty: 'сложность',
    correctAnswer: 'Ответ верный.',
    incorrectAnswer: 'Ответ неверный.',
    errorReason: 'Причина ошибки:',
    skillConfirmed: 'Навык подтверждён, сложность повышена. Контрольная точка:',
    repeatStep: 'Повторите шаг алгоритма:',
    refFormula: 'Опорная формула:',
    nextTask: 'Следующее задание',
    askMentor: 'Разобрать с ИИ-ментором',
  },
  kz: {
    lang: 'kz',
    loading: 'Жүктелуде…',
    noProfileTitle: 'Профиль жасалмаған',
    noProfileSub: 'Практикум тапсырмаларды сіздің деңгейіңізге сай таңдайды.',
    createProfile: 'Профиль жасау',
    eyebrow: 'Практикум',
    selectModule: 'Модульді таңдаңыз',
    selectModuleSub: 'Модуль ішіндегі күрделілік динамикалық түрде таңдалады: платформа табыс ықтималдығын 75% шамасында ұстайды.',
    new: 'жаңа',
    tasks: 'тапсырма',
    entWeight: 'ҰБТ салмағы',
    mastery: 'меңгеру',
    noTasks: 'Тапсырмалар жоқ',
    startSession: 'Сессияны бастау',
    sessionFinished: 'Сессия аяқталды',
    sessionResults: 'Сессия қорытындысы',
    correct: 'Дұрыс',
    topicMastery: 'Тақырыпты меңгеру',
    entScoreForecast: 'ҰБТ болжамы',
    sessionGain: 'сессия үшін',
    moreSession: 'Тағы сессия',
    otherModule: 'Басқа модуль',
    toDashboard: 'Кабинетке',
    successChance: 'табыс мүмкіндігі ≈',
    taskOf: 'тапсырма',
    of: ' / ',
    rightAnswers: 'дұрыс',
    difficulty: 'күрделілік',
    correctAnswer: 'Жауап дұрыс.',
    incorrectAnswer: 'Жауап қате.',
    errorReason: 'Қате себебі:',
    skillConfirmed: 'Дағды расталды, күрделілік артты. Бақылау нүктесі:',
    repeatStep: 'Алгоритм қадамын қайталаңыз:',
    refFormula: 'Тірек формула:',
    nextTask: 'Келесі тапсырма',
    askMentor: 'AI-ментормен талдау',
  },
  en: {
    lang: 'en',
    loading: 'Loading...',
    noProfileTitle: 'Profile not created',
    noProfileSub: 'The practice selects tasks tailored to your level.',
    createProfile: 'Create Profile',
    eyebrow: 'Practice',
    selectModule: 'Select a Module',
    selectModuleSub: 'Difficulty within the module adapts dynamically, maintaining a ~75% success probability for optimal growth.',
    new: 'new',
    tasks: 'tasks',
    entWeight: 'ENT weight',
    mastery: 'mastery',
    noTasks: 'No tasks',
    startSession: 'Start Session',
    sessionFinished: 'Session Completed',
    sessionResults: 'Session Results',
    correct: 'Correct',
    topicMastery: 'Topic Mastery',
    entScoreForecast: 'ENT Forecast',
    sessionGain: 'for this session',
    moreSession: 'Another Session',
    otherModule: 'Other Module',
    toDashboard: 'To Dashboard',
    successChance: 'success chance ≈',
    taskOf: 'task',
    of: 'of',
    rightAnswers: 'correct',
    difficulty: 'difficulty',
    correctAnswer: 'Correct answer.',
    incorrectAnswer: 'Incorrect answer.',
    errorReason: 'Error reason:',
    skillConfirmed: 'Skill confirmed, difficulty increased. Checkpoint:',
    repeatStep: 'Repeat algorithm step:',
    refFormula: 'Reference formula:',
    nextTask: 'Next Task',
    askMentor: 'Analyze with AI Mentor',
  },
};

export default function Practice() {
  const r = useRouter();
  const st = useStore();
  const { lang } = useLanguage();
  const t = dict[lang];

  const [topicId, setTopicId] = useState<string | null>(null);
  const [item, setItem] = useState<Item | null>(null);
  const [chosen, setChosen] = useState<number | null>(null);
  const [delta, setDelta] = useState<{ before: number; after: number; correct: boolean } | null>(null);
  const [asked, setAsked] = useState(0);
  const [right, setRight] = useState(0);
  const [start, setStart] = useState(0);
  const [finished, setFinished] = useState(false);

  const subjects = st.profile?.subjects ?? ['math', 'physics'];
  const topics = useMemo(() => {
    const baseTopics = relevantTopics(subjects, []);
    const custom = st.customTopics.filter((customTopic) => !baseTopics.some((baseTopic) => baseTopic.id === customTopic.id));
    return [...baseTopics, ...custom];
  }, [subjects, st.customTopics]);
  const allTopics = useMemo(() => [...TOPICS, ...st.customTopics], [st.customTopics]);
  const topic = allTopics.find((itemObj) => itemObj.id === topicId) ?? null;
  const displayTopic = topic ? localizeTopic(topic, lang) : null;
  const displayItem = item ? localizeItem(item, lang) : null;
  const theta = useMemo(() => estimateTheta([]).theta + ((st.mastery[topicId ?? ''] ?? 0.3) - 0.5) * 2, [st.mastery, topicId]);

  const next = (tid: string) => {
    const p = itemsOf(tid, st.customItems);
    setItem(pickPractice(p, ((st.mastery[tid] ?? 0.3) - 0.5) * 2, st.seenItems));
    setChosen(null);
    setDelta(null);
  };

  const begin = (tid: string) => {
    setTopicId(tid);
    setStart(st.profile ? forecast(subjects, st.mastery, st.attemptsByTopic, st.customTopics, st.profile.target).predicted : 0);
    setAsked(0); setRight(0); setFinished(false);
    next(tid);
  };

  const submit = (i: number) => {
    if (!item || chosen !== null) return;
    setChosen(i);
    const res = st.answer(item.topicId, item.id, i === item.answer);
    setDelta({ ...res, correct: i === item.answer });
    setAsked((v) => v + 1);
    if (i === item.answer) setRight((v) => v + 1);
  };

  const cont = () => {
    if (asked >= LEN) {
      if (st.profile) {
        st.pushScore(forecast(subjects, st.mastery, st.attemptsByTopic, st.customTopics, st.profile.target).predicted);
      }
      setFinished(true);
      return;
    }
    if (topicId) next(topicId);
  };

  if (!st.loaded) return <Shell><div className="wrap py-20 text-sm text-slate-500">{t.loading}</div></Shell>;
  if (!st.profile) {
    return (
      <Shell>
        <div className="wrap max-w-xl py-20 text-center">
          <Title title={t.noProfileTitle} sub={t.noProfileSub} />
          <Btn className="mt-6" onClick={() => r.push('/onboarding')}>{t.createProfile}</Btn>
        </div>
      </Shell>
    );
  }

  if (!topicId || !topic) {
    return (
      <Shell>
        <div className="wrap py-10">
          <div className="flex justify-between items-center mb-6">
            <Title eyebrow={t.eyebrow} title={t.selectModule} sub={t.selectModuleSub} />
          </div>
          <div className="mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {topics.map((itemObj) => {
              const pL = st.mastery[itemObj.id] ?? 0;
              const n = itemsOf(itemObj.id, st.customItems).length;
              return (
                <Card key={itemObj.id} className="transition-colors hover:border-[#10B981]/50">
                  <div className="flex items-start justify-between gap-2">
                    <p className="text-[14px] font-medium leading-snug">{localizeTopic(itemObj, lang).title}</p>
                    {itemObj.id.startsWith('c-') && <Badge color="#8B5CF6">{t.new}</Badge>}
                  </div>
                  <p className="num mt-2 text-[11px] text-slate-500">{LEN} {t.tasks} · {t.entWeight} {Math.round(itemObj.weight * 100)}%</p>
                  <div className="mt-3"><Bar value={pL} /></div>
                  <p className="num mt-2 text-[11px] text-slate-500">{t.mastery} {Math.round(pL * 100)}%</p>
                  <Btn size="sm" className="mt-4 w-full" onClick={() => begin(itemObj.id)} disabled={n === 0}>
                    {n === 0 ? t.noTasks : t.startSession}
                  </Btn>
                </Card>
              );
            })}
          </div>
        </div>
      </Shell>
    );
  }

  if (finished) {
    const after = st.mastery[topicId] ?? 0;
    const now = forecast(subjects, st.mastery, st.attemptsByTopic, st.customTopics, st.profile.target).predicted;
    const diff = now - start;
    return (
      <Shell>
        <div className="wrap max-w-3xl py-10">
          <div className="flex justify-between items-center mb-4">
            <Badge color="#10B981">{t.sessionFinished}</Badge>
          </div>
          <Title title={t.sessionResults} sub={displayTopic?.title ?? topic.title} />
          <div className="mt-6 grid gap-4 sm:grid-cols-3">
            <Card><Stat label={t.correct} value={`${right} / ${asked}`} /></Card>
            <Card><Stat label={t.topicMastery} value={`${Math.round(after * 100)}%`} /></Card>
            <Card><Stat label={t.entScoreForecast} value={now} hint={`${diff >= 0 ? '+' : ''}${diff} ${t.sessionGain}`} /></Card>
          </div>
          <div className="mt-6 flex flex-col gap-3 sm:flex-row">
            <Btn onClick={() => begin(topicId)}>{t.moreSession}</Btn>
            <Btn variant="ghost" onClick={() => setTopicId(null)}>{t.otherModule}</Btn>
            <Btn variant="ghost" onClick={() => r.push('/dashboard')}>{t.toDashboard}</Btn>
          </div>
        </div>
      </Shell>
    );
  }

  const pL = st.mastery[topicId] ?? 0;

  return (
    <Shell>
      <div className="wrap max-w-3xl space-y-4 py-10">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <Title eyebrow={t.eyebrow} title={displayTopic?.title ?? topic.title} />
          <div className="flex items-center gap-3">
            {item && <Badge color="#8B5CF6">{t.successChance} {Math.round(pCorrect(theta, item) * 100)}%</Badge>}
          </div>
        </div>

        <Card className="py-4">
          <div className="flex justify-between text-[12px] text-slate-400">
            <span>{t.topicMastery}</span><span className="num">{Math.round(pL * 100)}%</span>
          </div>
          <div className="mt-2"><Bar value={pL} /></div>
          <div className="num mt-2 flex justify-between text-[11px] text-slate-500">
            <span>{t.taskOf} {Math.min(asked + 1, LEN)} {t.of} {LEN}</span><span>{right} {t.rightAnswers}</span>
          </div>
        </Card>

        {item && (
          <Card>
            <div className="flex flex-wrap gap-2">
              <Badge>{displayItem?.skill ?? item.skill}</Badge>
              <Badge color={item.b > 0.8 ? '#F43F5E' : item.b > 0.2 ? '#F59E0B' : '#10B981'}>{t.difficulty} {item.b.toFixed(1)}</Badge>
            </div>
            <p className="mt-5 text-[17px] font-medium leading-relaxed">{displayItem?.stem ?? item.stem}</p>
            <div className="mt-6 space-y-2.5">
              {(displayItem?.options ?? item.options).map((o, i) => {
                const isAnswer = i === item.answer;
                const isChosen = i === chosen;
                const shown = chosen !== null;
                return (
                  <button key={i} disabled={shown} onClick={() => submit(i)}
                    className={cx('flex w-full items-center gap-3 rounded-xl border px-4 py-3.5 text-left text-[15px] transition-all',
                      !shown && 'border-[#1F2937] bg-[#0F1622] hover:border-[#10B981]/60 hover:bg-[#10B981]/5',
                      shown && isAnswer && 'border-[#10B981]/60 bg-[#10B981]/10',
                      shown && isChosen && !isAnswer && 'border-[#F43F5E]/60 bg-[#F43F5E]/10',
                      shown && !isAnswer && !isChosen && 'border-[#1F2937] opacity-50')}>
                    <span className="num grid h-7 w-7 shrink-0 place-items-center rounded-lg border border-[#1F2937] text-xs text-slate-400">
                      {shown && isAnswer ? '✓' : shown && isChosen ? '✕' : String.fromCharCode(65 + i)}
                    </span>
                    {o}
                  </button>
                );
              })}
            </div>
          </Card>
        )}

        {delta && item && (
          <Card className={cx('animate-up', delta.correct ? 'border-[#10B981]/40 bg-[#10B981]/5' : 'border-[#F43F5E]/40 bg-[#F43F5E]/5')}>
            <div className="flex flex-wrap items-center justify-between gap-2">
              <p className={cx('text-[15px] font-semibold', delta.correct ? 'text-[#10B981]' : 'text-[#F43F5E]')}>
                {delta.correct ? t.correctAnswer : t.incorrectAnswer}
              </p>
              <Badge color="#8B5CF6">
                {t.mastery} {Math.round(delta.before * 100)}% → {Math.round(delta.after * 100)}%
              </Badge>
            </div>
            <p className="mt-3 text-[14px] leading-relaxed">{displayItem?.explain ?? item.explain}</p>
            {!delta.correct && displayItem?.trap && (
              <p className="mt-2 text-[13px] leading-relaxed text-slate-400">{t.errorReason} {displayItem.trap}</p>
            )}
            <p className="mt-3 rounded-xl border border-[#1F2937] bg-[#0F1622] p-3 text-[13px] leading-relaxed text-slate-400">
              {delta.correct
                ? `${t.skillConfirmed} ${(displayTopic ?? topic).theory.mistake}`
                : `${t.repeatStep} ${(displayTopic ?? topic).theory.steps[0]}. ${t.refFormula} ${(displayTopic ?? topic).theory.formulas[0]}`}
            </p>
            <div className="mt-5 flex flex-col gap-2.5 sm:flex-row">
              <Btn onClick={cont}>{asked >= LEN ? t.sessionResults : t.nextTask} →</Btn>
              <Btn variant="ghost" onClick={() => r.push('/mentor')}>{t.askMentor}</Btn>
            </div>
          </Card>
        )}
      </div>
    </Shell>
  );
}
