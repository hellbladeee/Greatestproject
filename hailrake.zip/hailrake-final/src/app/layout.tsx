import { StoreProvider } from '@/lib/state';
import { LanguageProvider } from '@/context/LanguageContext';
import './globals.css';
import { GlobalLanguageBar } from '@/components/GlobalLanguageBar';

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ru">
      <body>
        <StoreProvider>
          <LanguageProvider><GlobalLanguageBar />{children}</LanguageProvider>
        </StoreProvider>
      </body>
    </html>
  );
}