'use client';
import { useRouter } from 'next/navigation';
import { useLanguage } from '@/context/LanguageContext';
import { useMemo, useState } from 'react';
import { ITEMS, SUBJECTS, TOPICS, type Item } from '@/lib/data';
import { localizeItem, localizeSubject, localizeTopic } from '@/lib/content';
import { bkt, estimateTheta, forecast, pickDiagnostic, relevantTopics, seedMastery } from '@/lib/engine';
import { useStore } from '@/lib/state';
import { Badge, Bar, Btn, Card, Shell, Stat, Title, cx } from '@/components/ui';


const dict = {
  ru: {
    loading: 'Загрузка…',
    noProfileTitle: 'Сначала создайте профиль',
    noProfileSub: 'Диагностика подбирает задания по профильным предметам и классу.',
    noProfileBtn: 'Создать профиль',
    badgeDone: 'Диагностика завершена',
    doneTitle: 'Уровень измерен, пробелы найдены',
    doneSub: 'Оценка получена методом максимума апостериорной вероятности (IRT), освоение тем инициализировано моделью BKT.',
    forecastLabel: 'Прогноз балла ЕНТ пересчитан',
    correctCount: 'Верных ответов',
    adaptiveCount: 'Заданий адаптивно',
    adaptiveHint: 'по информации Фишера',
    gapsCount: 'Пробелов найдено',
    subjectLevelTitle: 'Уровень по предметам (θ)',
    percentile: 'перцентиль',
    priorityGapsTitle: 'Приоритетные пробелы',
    noGapsText: 'Критических пробелов нет — переходите к сложным заданиям.',
    toDashboard: 'Открыть личный кабинет →',
    toPractice: 'Сразу в практикум',
    adaptiveBadge: 'Адаптивный режим',
    pickTask: 'Подбор задания…',
    difficultyLabel: 'сложность b =',
    reviewHint: 'Разбор появится после завершения — это сохраняет несмещённость оценки уровня.',
  },
  kz: {
    loading: 'Жүктелуде…',
    noProfileTitle: 'Алдымен профиль жасаңыз',
    noProfileSub: 'Диагностика тапсырмаларды бейіндік пәндер мен сынып бойынша таңдайды.',
    noProfileBtn: 'Профиль жасау',
    badgeDone: 'Диагностика аяқталды',
    doneTitle: 'Деңгей өлшенді, олқылықтар табылды',
    doneSub: 'Бағалау апостериорлық ықтималдық максимумы әдісімен (IRT) алынды, тақырыптарды меңгеру BKT моделімен іске қосылды.',
    forecastLabel: 'ҰБТ балының болжамы қайта есептелді',
    correctCount: 'Дұрыс жауаптар',
    adaptiveCount: 'Адаптивті тапсырмалар',
    adaptiveHint: 'Фишер ақпараты бойынша',
    gapsCount: 'Олқылықтар табылды',
    subjectLevelTitle: 'Пәндер бойынша деңгей (θ)',
    percentile: 'перцентиль',
    priorityGapsTitle: 'Басым олқылықтар',
    noGapsText: 'Критикалық олқылықтар жоқ — күрделі тапсырмаларға көшіңіз.',
    toDashboard: 'Жеке кабинетті ашу →',
    toPractice: 'Практикумға бірден өту',
    adaptiveBadge: 'Адаптивті режим',
    pickTask: 'Тапсырманы таңдау…',
    difficultyLabel: 'қиындыгы b =',
    reviewHint: 'Талдау аяқталғаннан кейін пайда болады — бұл деңгейді бағалаудың бұрмаланбауын сақтайды.',
  },
  en: {
    loading: 'Loading…',
    noProfileTitle: 'Create a profile first',
    noProfileSub: 'Diagnostics selects tasks based on your profile subjects and grade.',
    noProfileBtn: 'Create Profile',
    badgeDone: 'Diagnostics Completed',
    doneTitle: 'Level measured, gaps identified',
    doneSub: 'Estimation obtained via Maximum A Posteriori (IRT), topic mastery initialized with the BKT model.',
    forecastLabel: 'ENT score forecast recalculated',
    correctCount: 'Correct Answers',
    adaptiveCount: 'Adaptive Tasks',
    adaptiveHint: 'via Fisher information',
    gapsCount: 'Gaps Found',
    subjectLevelTitle: 'Level by Subject (θ)',
    percentile: 'percentile',
    priorityGapsTitle: 'Priority Gaps',
    noGapsText: 'No critical gaps — proceed to advanced tasks.',
    toDashboard: 'Open Dashboard →',
    toPractice: 'Go straight to Practice',
    adaptiveBadge: 'Adaptive Mode',
    pickTask: 'Selecting task…',
    difficultyLabel: 'difficulty b =',
    reviewHint: 'Review will appear after completion — this keeps the level estimation unbiased.',
  },
};

const LEN = 12;

export default function Diagnostic() {
  const r = useRouter();
  const st = useStore();
  const { lang } = useLanguage();
  const t = dict[lang];

  const [answers, setAnswers] = useState<{ item: Item; correct: boolean }[]>([]);
  const [done, setDone] = useState(false);
  const [result, setResult] = useState<{ before: number; after: number; gaps: { id: string; title: string; pL: number }[]; theta: Record<string, number> } | null>(null);

  const subjects = st.profile?.subjects ?? ['math', 'physics'];
  const topics = useMemo(() => relevantTopics(subjects, st.customTopics), [subjects, st.customTopics]);
  const pool = useMemo(() => {
    const ids = new Set(topics.map((item) => item.id));
    return [...ITEMS, ...st.customItems].filter((i) => ids.has(i.topicId));
  }, [topics, st.customItems]);

  const total = Math.min(LEN, pool.length);
  const theta = useMemo(() => estimateTheta(answers).theta, [answers]);

  const current = useMemo(() => {
    if (done || answers.length >= total) return null;
    const counts: Record<string, number> = {};
    answers.forEach((a) => { counts[a.item.topicId] = (counts[a.item.topicId] || 0) + 1; });
    return pickDiagnostic(pool, theta, new Set(answers.map((a) => a.item.id)), counts);
  }, [answers, done, pool, theta, total]);

  const finish = (list: { item: Item; correct: boolean }[]) => {
    const before = st.profile
      ? forecast(subjects, st.mastery, st.attemptsByTopic, st.customTopics, st.profile.target).predicted
      : 0;

    const thetaBySubject: Record<string, number> = {};
    for (const s of SUBJECTS) {
      const sub = list.filter((a) => topics.find((tp) => tp.id === a.item.topicId)?.subject === s.id);
      if (sub.length) thetaBySubject[s.id] = estimateTheta(sub).theta;
    }

    const mastery: Record<string, number> = {};
    const counts: Record<string, number> = {};
    for (const tp of topics) {
      const rows = list.filter((a) => a.item.topicId === tp.id);
      const th = thetaBySubject[tp.subject] ?? 0;
      const avg = rows.length
        ? { a: rows.reduce((x, v) => x + v.item.a, 0) / rows.length, b: rows.reduce((x, v) => x + v.item.b, 0) / rows.length, c: rows.reduce((x, v) => x + v.item.c, 0) / rows.length }
        : { a: 1.3, b: 0, c: 0.2 };
      let pL = seedMastery(th, avg);
      rows.forEach((a) => { pL = bkt(pL, a.correct); });
      mastery[tp.id] = pL;
      counts[tp.id] = rows.length;
    }

    const after = st.profile
      ? forecast(subjects, { ...st.mastery, ...mastery }, { ...st.attemptsByTopic, ...counts }, st.customTopics, st.profile.target).predicted
      : 0;

    st.applyDiagnostic(mastery, counts, before);
    st.pushScore(after);
    setResult({
      before, after,
      theta: thetaBySubject,
      gaps: topics.map((tp) => ({ id: tp.id, title: tp.title, pL: mastery[tp.id] ?? 0 }))
        .filter((g) => g.pL < 0.6).sort((a, b) => a.pL - b.pL).slice(0, 5),
    });
    setDone(true);
  };

  const answer = (idx: number) => {
    if (!current) return;
    const next = [...answers, { item: current, correct: idx === current.answer }];
    setAnswers(next);
    if (next.length >= total) finish(next);
  };

  if (!st.loaded) return <Shell><div className="wrap py-20 text-sm text-slate-500">{t.loading}</div></Shell>;

  if (!st.profile) {
    return (
      <Shell>
        <div className="wrap max-w-xl py-20 text-center">
          <Title title={t.noProfileTitle} sub={t.noProfileSub} />
          <Btn className="mt-6" onClick={() => r.push('/onboarding')}>{t.noProfileBtn}</Btn>
        </div>
      </Shell>
    );
  }

  if (done && result) {
    const delta = result.after - result.before;
    const correct = answers.filter((a) => a.correct).length;
    return (
      <Shell>
        <div className="wrap max-w-3xl py-10">
          <div className="flex items-center justify-between gap-4">
            <Badge color="#10B981">{t.badgeDone}</Badge>
          </div>
          <div className="mt-4">
            <Title title={t.doneTitle} sub={t.doneSub} />
          </div>

          <Card className="mt-6 animate-up">
            <p className="text-[13px] text-slate-400">{t.forecastLabel}</p>
            <div className="mt-3 flex items-end gap-4">
              <span className="num text-2xl text-slate-500 line-through">{result.before}</span>
              <span className="num text-5xl font-bold text-[#10B981]">{result.after}</span>
              <span className="num mb-1 text-sm text-slate-400">/ {st.profile.target}</span>
              {delta !== 0 && (
                <span className={cx('num mb-1 rounded-lg px-2 py-1 text-sm', delta > 0 ? 'bg-[#10B981]/15 text-[#10B981]' : 'bg-[#F43F5E]/15 text-[#F43F5E]')}>
                  {delta > 0 ? '+' : ''}{delta}
                </span>
              )}
            </div>
            <div className="mt-4"><Bar value={result.after / st.profile.target} /></div>
          </Card>

          <div className="mt-4 grid gap-4 sm:grid-cols-3">
            <Card><Stat label={t.correctCount} value={`${correct} / ${answers.length}`} /></Card>
            <Card><Stat label={t.adaptiveCount} value={answers.length} hint={t.adaptiveHint} /></Card>
            <Card><Stat label={t.gapsCount} value={result.gaps.length} /></Card>
          </div>

          <Card className="mt-4">
            <p className="text-[15px] font-semibold">{t.subjectLevelTitle}</p>
            <div className="mt-4 space-y-3">
              {Object.entries(result.theta).map(([sid, th]) => {
                const perc = Math.round(100 / (1 + Math.exp(-1.7 * th)));
                return (
                  <div key={sid}>
                    <div className="flex justify-between text-[13px]">
                      <span>{(() => { const s = SUBJECTS.find((x) => x.id === sid); return s ? localizeSubject(s, lang).title : sid; })()}</span>
                      <span className="num text-slate-400">θ = {th.toFixed(2)} · {t.percentile} {perc}</span>
                    </div>
                    <div className="mt-1.5"><Bar value={perc / 100} /></div>
                  </div>
                );
              })}
            </div>
          </Card>

          <Card className="mt-4">
            <p className="text-[15px] font-semibold">{t.priorityGapsTitle}</p>
            {result.gaps.length === 0
              ? <p className="mt-3 text-sm text-slate-400">{t.noGapsText}</p>
              : <div className="mt-4 space-y-3">
                  {result.gaps.map((g) => (
                    <div key={g.id}>
                      <div className="flex justify-between text-[13px]">
                        <span>{localizeTopic(TOPICS.find((x) => x.id === g.id) ?? { id: g.id, subject: 'math', title: g.title, weight: 0, theory: { core: '', formulas: [], steps: [], mistake: '' } }, lang).title}</span><span className="num text-slate-400">{Math.round(g.pL * 100)}%</span>
                      </div>
                      <div className="mt-1.5"><Bar value={g.pL} /></div>
                    </div>
                  ))}
                </div>}
          </Card>

          <div className="mt-6 flex flex-col gap-3 sm:flex-row">
            <Btn onClick={() => r.push('/dashboard')}>{t.toDashboard}</Btn>
            <Btn variant="ghost" onClick={() => r.push('/practice')}>{t.toPractice}</Btn>
          </div>
        </div>
      </Shell>
    );
  }

  return (
    <Shell>
      <div className="wrap max-w-3xl py-10">
        <div className="flex items-center justify-between">
          <Badge color="#8B5CF6">{t.adaptiveBadge}</Badge>
          <div className="flex items-center gap-3">
            <span className="num text-xs text-slate-400">{answers.length + 1} / {total}</span>
          </div>
        </div>
        <div className="mt-4"><Bar value={answers.length / total} color="#8B5CF6" /></div>

        {!current ? (
          <Card className="mt-8"><p className="text-sm text-slate-400">{t.pickTask}</p></Card>
        ) : (
          <Card className="mt-8 animate-up">
            <div className="flex flex-wrap gap-2">
              <Badge>{localizeTopic(TOPICS.concat(st.customTopics).find((tp) => tp.id === current.topicId) ?? { id: current.topicId, subject: 'math', title: current.topicId, weight: 0, theory: { core: '', formulas: [], steps: [], mistake: '' } }, lang).title}</Badge>
              <Badge color="#8B5CF6">{localizeItem(current, lang).skill}</Badge>
              <Badge color={current.b > 0.8 ? '#F43F5E' : current.b > 0.2 ? '#F59E0B' : '#10B981'}>
                {t.difficultyLabel} {current.b.toFixed(1)}
              </Badge>
            </div>
            <p className="mt-6 text-[17px] font-medium leading-relaxed">{localizeItem(current, lang).stem}</p>
            <div className="mt-6 space-y-2.5">
              {localizeItem(current, lang).options.map((o, i) => (
                <button key={i} onClick={() => answer(i)}
                  className="flex w-full items-center gap-3 rounded-xl border border-[#1F2937] bg-[#0F1622] px-4 py-3.5 text-left text-[15px] transition-all hover:border-[#10B981]/60 hover:bg-[#10B981]/5">
                  <span className="num grid h-7 w-7 shrink-0 place-items-center rounded-lg border border-[#1F2937] text-xs text-slate-400">
                    {String.fromCharCode(65 + i)}
                  </span>
                  {o}
                </button>
              ))}
            </div>
            <p className="mt-5 text-xs text-slate-500">
              {t.reviewHint}
            </p>
          </Card>
        )}
      </div>
    </Shell>
  );
}
