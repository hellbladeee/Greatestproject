'use client';
import { useMemo, useState, useEffect } from 'react';
import { useLanguage } from '@/context/LanguageContext';
import { SUBJECTS, TOPICS, type Item, type SubjectId, type Topic } from '@/lib/data';
import { localizeRegion, localizeSchool, localizeSubject, localizeTopic } from '@/lib/content';
import { buildClass, TIER_COLOR, type ClassStudent } from '@/lib/engine';
import { useStore } from '@/lib/state';
import { supabase } from '@/lib/supabaseClient';
import { fetchClassStudents, createStudentAccount, deleteStudentAccount, saveClassContent } from '@/lib/sync';
import { Badge, Bar, Btn, Card, Field, Input, Sel, Shell, Stat, Title, cx } from '@/components/ui';


const dict = {
  ru: {
    portal: 'Кабинет преподавателя',
    loginTitle: 'Вход по паролю',
    loginSub: 'Введите код доступа для управления классом и модулями',
    passPlaceholder: 'Пароль (например: demo123)',
    loginPlaceholder: 'Логин (например: teacher1)',
    wrongPass: 'Неверный логин или пароль',
    signIn: 'Войти в систему →',
    activeMode: 'Режим учителя активен',
    logout: 'Выйти',
    eyebrow: 'Панель управления',
    title: 'Панель учителя',
    sub: 'Класс сегментирован по прогнозу балла ЕНТ. Проблемные темы ранжируются по среднему освоению, новые модули добавляются без разработки.',
    students: 'Учеников',
    activeGroup: 'активная группа',
    avgPred: 'Средний прогноз',
    maxScore: 'из 140 баллов',
    atRisk: 'В зоне риска',
    intervention: 'требуется вмешательство',
    avgAcc: 'Средняя точность',
    reset: 'Сбросить',
    sortScore: 'Сорт.: прогноз ↑',
    sortAcc: 'Сорт.: точность ↓',
    sortName: 'Сорт.: имя',
    you: 'вы',
    liveBadge: 'реальный',
    classCodeLabel: 'Код вашего класса',
    classCodeHint: 'Дайте этот код ученикам — они впишут его в свой профиль.',
    manageTitle: 'Ученики класса',
    addStudentTitle: 'Добавить ученика',
    fieldName: 'Имя',
    fieldGrade: 'Класс',
    fieldLogin: 'Логин',
    fieldPassword: 'Пароль',
    addStudentBtn: 'Добавить ученика',
    deleteBtn: 'Удалить',
    addErrName: 'Укажите имя (минимум 2 символа).',
    addErrLogin: 'Логин — минимум 3 символа.',
    addErrPassword: 'Пароль — минимум 3 символа.',
    noRealStudents: 'Пока нет ни одного реального ученика в этом классе.',
    attempts: 'попыток',
    recSys: 'Рекомендация системы',
    startWith: 'Начать с темы',
    control: 'Контроль',
    problemTopics: 'Проблемные темы класса',
    problemSub: 'Среднее освоение по группе. Красная зона — ниже 40%.',
    belowThreshold: 'ниже порога у',
    studentsCount: 'учеников',
    moduleBuilder: 'Конструктор учебных модулей',
    builderSub: 'Добавленные темы и задания сразу попадают в адаптивный банк и участвуют в подборе сложности для учеников.',
    newTopic: 'Новая тема',
    topicName: 'Название темы',
    topicPlaceholder: 'Тригонометрические уравнения',
    subject: 'Предмет',
    entWeight: 'Вес в ЕНТ:',
    addTopicBtn: 'Добавить тему',
    newItem: 'Новое задание',
    topicLabel: 'Тема',
    stemLabel: 'Условие задания',
    stemPlaceholder: 'Решите уравнение sin x = 1/2 на [0; π]',
    optionsLabel: 'Варианты ответа',
    optionsHint: 'Отметьте кружком верный вариант.',
    optPlaceholder: 'Вариант',
    explainLabel: 'Разбор для ученика',
    explainPlaceholder: 'Алгоритм решения и типичная ошибка',
    addItemBtn: 'Добавить задание',
    avgScorePrefix: 'ср. балл', accuracyPrefix: 'точность', gradeShort: 'кл.',
    flashShortTopic: 'Название темы слишком короткое.',
    flashTopicAdded: (name: string) => `Тема «${name}» добавлена и доступна ученикам.`,
    flashShortItem: 'Условие задания слишком короткое.',
    flashFourOptions: 'Заполните все четыре варианта ответа.',
    flashExplain: 'Добавьте разбор — он показывается ученику.',
    flashItemAdded: 'Задание добавлено в адаптивный банк и сразу участвует в подборе.',
    customTopicCore: 'Тема добавлена учителем.', customTopicStep: 'Разобрать материал урока', customTopicMistake: 'Уточняется по результатам заданий.',
  },
  kz: {
    portal: 'Оқытушы кабинеті',
    loginTitle: 'Құпия сөзбен кіру',
    loginSub: 'Сынып пен модульдерді басқару үшін кіру кодын енгізіңіз',
    passPlaceholder: 'Құпия сөз (мысалы: demo123)',
    loginPlaceholder: 'Логин (мысалы: teacher1)',
    wrongPass: 'Логин немесе құпия сөз қате',
    signIn: 'Жүйеге кіру →',
    activeMode: 'Мұғалім режимі белсенді',
    logout: 'Шығу',
    eyebrow: 'Басқару панелі',
    title: 'Мұғалім панелі',
    sub: 'Сынып ҰБТ балының болжамы бойынша сегменттелген. Проблемалық тақырыптар орташа меңгерілуі бойынша реттеледі.',
    students: 'Оқушылар',
    activeGroup: 'белсенді топ',
    avgPred: 'Орташа болжам',
    maxScore: '140 баллдан',
    atRisk: 'Қауіп аймағында',
    intervention: 'араласу қажет',
    avgAcc: 'Орташа дәлдік',
    reset: 'Қалпына келтіру',
    sortScore: 'Сұрып.: болжам ↑',
    sortAcc: 'Сұрып.: дәлдік ↓',
    sortName: 'Сұрып.: аты',
    you: 'сіз',
    liveBadge: 'нақты',
    classCodeLabel: 'Сыныбыңыздың коды',
    classCodeHint: 'Бұл кодты оқушыларға беріңіз — олар оны профильге енгізеді.',
    manageTitle: 'Сынып оқушылары',
    addStudentTitle: 'Оқушы қосу',
    fieldName: 'Аты',
    fieldGrade: 'Сынып',
    fieldLogin: 'Логин',
    fieldPassword: 'Құпия сөз',
    addStudentBtn: 'Оқушыны қосу',
    deleteBtn: 'Жою',
    addErrName: 'Атын көрсетіңіз (кемінде 2 таңба).',
    addErrLogin: 'Логин — кемінде 3 таңба.',
    addErrPassword: 'Құпия сөз — кемінде 3 таңба.',
    noRealStudents: 'Бұл сыныпта әлі бірде-бір нақты оқушы жоқ.',
    attempts: 'әрекет',
    recSys: 'Жүйе ұсынысы',
    startWith: 'Мына тақырыптан бастау',
    control: 'Бақылау',
    problemTopics: 'Сыныптың проблемалық тақырыптары',
    problemSub: 'Топ бойынша орташа меңгеру. Қызыл аймақ — 40%-дан төмен.',
    belowThreshold: 'деңгейден төмен:',
    studentsCount: 'оқушы',
    moduleBuilder: 'Оқу модульдерін құрастырушы',
    builderSub: 'Қосылған тақырыптар мен тапсырмалар бірден бейімдеу банкіне түседі.',
    newTopic: 'Жаңа тақырып',
    topicName: 'Тақырып атауы',
    topicPlaceholder: 'Тригонометриялық теңдеулер',
    subject: 'Пән',
    entWeight: 'ҰБТ-дағы салмағы:',
    addTopicBtn: 'Тақырыпты қосу',
    newItem: 'Жаңа тапсырма',
    topicLabel: 'Тақырып',
    stemLabel: 'Тапсырма шарты',
    stemPlaceholder: 'sin x = 1/2 теңдеуін шешіңіз',
    optionsLabel: 'Жауап нұсқалары',
    optionsHint: 'Дұрыс нұсқаны белгілеңіз.',
    optPlaceholder: 'Нұсқа',
    explainLabel: 'Оқушыға арналған талдау',
    explainPlaceholder: 'Шешу алгоритмі және қате',
    addItemBtn: 'Тапсырма қосу',
    avgScorePrefix: 'орт. балл', accuracyPrefix: 'дәлдік', gradeShort: 'сынып',
    flashShortTopic: 'Тақырып атауы тым қысқа.',
    flashTopicAdded: (name: string) => `«${name}» тақырыбы қосылды және оқушыларға қолжетімді.`,
    flashShortItem: 'Тапсырма шарты тым қысқа.',
    flashFourOptions: 'Барлық төрт жауап нұсқасын толтырыңыз.',
    flashExplain: 'Талдауды қосыңыз — ол оқушыға көрсетіледі.',
    flashItemAdded: 'Тапсырма бейімделгіш банкке қосылды және бірден іске қосылады.',
    customTopicCore: 'Тақырыпты мұғалім қосты.', customTopicStep: 'Сабақ материалын талдау', customTopicMistake: 'Тапсырма нәтижелері бойынша нақтыланады.',
  },
  en: {
    portal: 'Teacher Portal',
    loginTitle: 'Password Login',
    loginSub: 'Enter access code to manage class and modules',
    passPlaceholder: 'Password (e.g., demo123)',
    loginPlaceholder: 'Login (e.g., teacher1)',
    wrongPass: 'Incorrect login or password',
    signIn: 'Sign in →',
    activeMode: 'Teacher mode active',
    logout: 'Logout',
    eyebrow: 'Control Panel',
    title: 'Teacher Dashboard',
    sub: 'Class is segmented by predicted ENT score. Problem topics are ranked by average mastery, and new modules can be added easily.',
    students: 'Students',
    activeGroup: 'active group',
    avgPred: 'Avg Prediction',
    maxScore: 'out of 140',
    atRisk: 'At Risk Zone',
    intervention: 'intervention needed',
    avgAcc: 'Average Accuracy',
    reset: 'Reset',
    sortScore: 'Sort: prediction ↑',
    sortAcc: 'Sort: accuracy ↓',
    sortName: 'Sort: name',
    you: 'you',
    liveBadge: 'live',
    classCodeLabel: 'Your class code',
    classCodeHint: 'Give this code to students — they enter it in their profile.',
    manageTitle: 'Class students',
    addStudentTitle: 'Add a student',
    fieldName: 'Name',
    fieldGrade: 'Grade',
    fieldLogin: 'Login',
    fieldPassword: 'Password',
    addStudentBtn: 'Add student',
    deleteBtn: 'Delete',
    addErrName: 'Please enter a name (at least 2 characters).',
    addErrLogin: 'Login must be at least 3 characters.',
    addErrPassword: 'Password must be at least 3 characters.',
    noRealStudents: 'No real students in this class yet.',
    attempts: 'attempts',
    recSys: 'System Recommendation',
    startWith: 'Start with topic',
    control: 'Control',
    problemTopics: 'Class Problem Topics',
    problemSub: 'Average mastery by group. Red zone is below 40%.',
    belowThreshold: 'below threshold for',
    studentsCount: 'students',
    moduleBuilder: 'Module Builder',
    builderSub: 'Added topics and items instantly integrate into the adaptive difficulty core.',
    newTopic: 'New Topic',
    topicName: 'Topic Name',
    topicPlaceholder: 'Trigonometric equations',
    subject: 'Subject',
    entWeight: 'ENT Weight:',
    addTopicBtn: 'Add Topic',
    newItem: 'New Assignment',
    topicLabel: 'Topic',
    stemLabel: 'Problem Statement',
    stemPlaceholder: 'Solve sin x = 1/2 on [0; π]',
    optionsLabel: 'Answer Options',
    optionsHint: 'Select the correct option with the radio button.',
    optPlaceholder: 'Option',
    explainLabel: 'Student Explanation',
    explainPlaceholder: 'Solution algorithm and common mistake',
    addItemBtn: 'Add Assignment',
    avgScorePrefix: 'avg. score', accuracyPrefix: 'accuracy', gradeShort: 'grade',
    flashShortTopic: 'Topic name is too short.',
    flashTopicAdded: (name: string) => `Topic “${name}” was added and is now available to students.`,
    flashShortItem: 'Problem statement is too short.',
    flashFourOptions: 'Fill in all four answer options.',
    flashExplain: 'Add an explanation — it is shown to the student.',
    flashItemAdded: 'Assignment was added to the adaptive bank and is immediately used for difficulty selection.',
    customTopicCore: 'The topic was added by the teacher.', customTopicStep: 'Review the lesson material', customTopicMistake: 'Refined from assignment results.',
  },
};

export default function Teacher() {
  const st = useStore();
  const { lang } = useLanguage();
  const t = dict[lang];
  
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [login, setLoginInput] = useState('');
  const [password, setPassword] = useState('');
  const [authError, setAuthError] = useState(false);
  const [authLoading, setAuthLoading] = useState(false);
  const [classCode, setClassCode] = useState('');
  const [realStudents, setRealStudents] = useState<ClassStudent[]>([]);

  // Форма добавления ученика вручную из панели учителя.
  const [newName, setNewName] = useState('');
  const [newGrade, setNewGrade] = useState(11);
  const [newLogin, setNewLogin] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [addError, setAddError] = useState('');
  const [addBusy, setAddBusy] = useState(false);

  useEffect(() => {
    const savedLogin = sessionStorage.getItem('teacher_login');
    const savedCode = sessionStorage.getItem('teacher_class_code');
    if (savedLogin && savedCode) {
      setClassCode(savedCode);
      setIsAuthenticated(true);
    }
  }, []);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthLoading(true);
    setAuthError(false);
    const { data: rawData, error } = await supabase
      .rpc('verify_teacher', { p_login: login.trim(), p_password: password })
      .maybeSingle();
    const data = rawData as { login: string; name: string; class_code: string | null } | null;
    setAuthLoading(false);
    if (error || !data || !data.class_code) {
      setAuthError(true);
      return;
    }
    setClassCode(data.class_code);
    setIsAuthenticated(true);
    sessionStorage.setItem('teacher_login', data.login);
    sessionStorage.setItem('teacher_class_code', data.class_code);
  };

  const tierLabels: Record<string,string> = lang === 'kz'
    ? { 'Критическая зона': 'Критикалық аймақ', 'Зона риска': 'Қауіп аймағы', 'Стабильные': 'Тұрақты', 'Высокий потенциал': 'Жоғары әлеует' }
    : lang === 'en'
      ? { 'Критическая зона': 'Critical Zone', 'Зона риска': 'Risk Zone', 'Стабильные': 'Stable', 'Высокий потенциал': 'High Potential' }
      : { 'Критическая зона': 'Критическая зона', 'Зона риска': 'Зона риска', 'Стабильные': 'Стабильные', 'Высокий потенциал': 'Высокий потенциал' };

  const handleLogout = () => {
    setIsAuthenticated(false);
    sessionStorage.removeItem('teacher_login');
    sessionStorage.removeItem('teacher_class_code');
    setPassword('');
    setLoginInput('');
    setRealStudents([]);
  };

  const reloadStudents = () => {
    if (!classCode) return;
    fetchClassStudents(classCode, st.customTopics).then(setRealStudents);
  };

  // Загружаем реальных учеников этого класса из Supabase после входа.
  useEffect(() => {
    if (!isAuthenticated || !classCode) return;
    let cancelled = false;
    fetchClassStudents(classCode, st.customTopics).then((rows) => {
      if (!cancelled) setRealStudents(rows);
    });
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isAuthenticated, classCode]);

  const handleAddStudent = async (e: React.FormEvent) => {
    e.preventDefault();
    setAddError('');
    if (newName.trim().length < 2) return setAddError(t.addErrName);
    if (newLogin.trim().length < 3) return setAddError(t.addErrLogin);
    if (newPassword.trim().length < 3) return setAddError(t.addErrPassword);
    setAddBusy(true);
    try {
      await createStudentAccount(classCode, newName.trim(), newGrade, newLogin.trim(), newPassword.trim());
      setNewName(''); setNewLogin(''); setNewPassword('');
      reloadStudents();
    } catch (err) {
      setAddError(err instanceof Error ? err.message : String(err));
    } finally {
      setAddBusy(false);
    }
  };

  const handleDeleteStudent = async (id: string) => {
    await deleteStudentAccount(id);
    reloadStudents();
  };

  const [open, setOpen] = useState<string | null>(null);
  const [filter, setFilter] = useState('все');
  const [sort, setSort] = useState('score');
  const [flash, setFlash] = useState('');

  const [tTitle, setTTitle] = useState('');
  const [tSubject, setTSubject] = useState<SubjectId>('math');
  const [tWeight, setTWeight] = useState(0.25);
  const [iTopic, setITopic] = useState(TOPICS[0].id);
  const [iStem, setIStem] = useState('');
  const [iOpts, setIOpts] = useState(['', '', '', '']);
  const [iAns, setIAns] = useState(0);
  const [iExp, setIExp] = useState('');

  const allTopics = useMemo(() => [...TOPICS, ...st.customTopics], [st.customTopics]);

  const cohort = useMemo<ClassStudent[]>(() => {
    const base = buildClass(st.customTopics);
    return [...realStudents, ...base];
  }, [st.customTopics, realStudents]);

  const rows = useMemo(() => {
    const list = cohort.filter((s) => filter === 'все' || s.tier === filter);
    return [...list].sort((a, b) =>
      sort === 'name' ? a.name.localeCompare(b.name)
        : sort === 'acc' ? b.accuracy - a.accuracy
          : a.predicted - b.predicted);
  }, [cohort, filter, sort]);

  const kpi = useMemo(() => ({
    avg: Math.round(cohort.reduce((x, s) => x + s.predicted, 0) / (cohort.length || 1)),
    risk: cohort.filter((s) => s.tier === 'Критическая зона' || s.tier === 'Зона риска').length,
    acc: Math.round((cohort.reduce((x, s) => x + s.accuracy, 0) / (cohort.length || 1)) * 100),
  }), [cohort]);

  const problems = useMemo(() =>
    allTopics.map((item) => {
      const vals = cohort.map((s) => s.mastery[item.id] ?? 0);
      return {
        topic: item,
        avg: vals.reduce((a, b) => a + b, 0) / (vals.length || 1),
        below: vals.filter((v) => v < 0.5).length,
      };
    }).sort((a, b) => a.avg - b.avg), [allTopics, cohort]);

  const addTopic = () => {
    if (tTitle.trim().length < 4) return setFlash(t.flashShortTopic);
    const newT: Topic = {
      id: `c-${Date.now().toString(36)}`, subject: tSubject, title: tTitle.trim(), weight: tWeight,
      theory: { core: t.customTopicCore, formulas: ['—'], steps: [t.customTopicStep], mistake: t.customTopicMistake },
    };
    st.addTopic(newT);
    saveClassContent(classCode, [...st.customTopics, newT], st.customItems);
    setITopic(newT.id);
    setTTitle('');
    setFlash(t.flashTopicAdded(newT.title));
  };

  const addItem = () => {
    if (iStem.trim().length < 8) return setFlash(t.flashShortItem);
    if (iOpts.some((o) => !o.trim())) return setFlash(t.flashFourOptions);
    if (iExp.trim().length < 5) return setFlash(t.flashExplain);
    const it: Item = {
      id: `ci-${Date.now().toString(36)}`, topicId: iTopic, skill: t.newItem,
      stem: iStem.trim(), options: iOpts.map((o) => o.trim()), answer: iAns,
      explain: iExp.trim(), a: 1.3, b: 0.2, c: 0.2, custom: true,
    };
    st.addItem(it);
    saveClassContent(classCode, st.customTopics, [...st.customItems, it]);
    setIStem(''); setIOpts(['', '', '', '']); setIExp('');
    setFlash(t.flashItemAdded);
  };

  if (!st.loaded) {
    const loading = { ru: 'Загрузка…', kz: 'Жүктелуде…', en: 'Loading…' }[lang];
    return <Shell><div className="wrap py-20 text-sm text-slate-500">{loading}</div></Shell>;
  }

  if (!isAuthenticated) {
    return (
      <Shell>
        <div className="wrap max-w-md py-24">
          <Card className="p-8">
            <div className="flex justify-between items-center mb-4">
              <Badge color="#F59E0B">{t.portal}</Badge>
            </div>
            <Title title={t.loginTitle} sub={t.loginSub} />
            
            <form onSubmit={handleLogin} className="mt-6 space-y-4">
              <div>
                <input
                  type="text"
                  placeholder={t.loginPlaceholder}
                  value={login}
                  onChange={(e) => setLoginInput(e.target.value)}
                  className="w-full rounded-xl border border-[#1F2937] bg-[#0F1622] px-4 py-3 text-sm text-white focus:border-[#F59E0B] focus:outline-none"
                />
              </div>
              <div>
                <input
                  type="password"
                  placeholder={t.passPlaceholder}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full rounded-xl border border-[#1F2937] bg-[#0F1622] px-4 py-3 text-sm text-white focus:border-[#F59E0B] focus:outline-none"
                />
                {authError && <p className="mt-2 text-xs text-[#F43F5E]">{t.wrongPass}</p>}
              </div>

              <Btn className="w-full bg-[#F59E0B] text-black hover:bg-[#F59E0B]/90" type="submit">
                {authLoading ? '…' : t.signIn}
              </Btn>
            </form>
          </Card>
        </div>
      </Shell>
    );
  }

  return (
    <Shell>
      <div className="wrap space-y-4 py-10">
        <div className="flex justify-between items-center">
          <Badge color="#F59E0B">{t.activeMode}</Badge>
          <div className="flex items-center gap-3">
            <Btn size="sm" variant="ghost" onClick={handleLogout}>{t.logout}</Btn>
          </div>
        </div>

        <Title eyebrow={t.eyebrow} title={t.title} sub={t.sub} />

        <Card className="border-[#F59E0B]/40 bg-[#F59E0B]/8">
          <p className="text-[12px] font-medium text-[#F59E0B]">{t.classCodeLabel}</p>
          <p className="num mt-1 text-3xl font-bold tracking-widest text-white">{classCode}</p>
          <p className="mt-1.5 text-[12px] text-slate-400">{t.classCodeHint}</p>
        </Card>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Card><Stat label={t.students} value={cohort.length} hint={t.activeGroup} /></Card>
          <Card><Stat label={t.avgPred} value={kpi.avg} hint={t.maxScore} /></Card>
          <Card><Stat label={t.atRisk} value={kpi.risk} hint={t.intervention} /></Card>
          <Card><Stat label={t.avgAcc} value={`${kpi.acc}%`} /></Card>
        </div>

        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {['Критическая зона', 'Зона риска', 'Стабильные', 'Высокий потенциал'].map((tier) => {
            const list = cohort.filter((s) => s.tier === tier);
            return (
              <button key={tier} onClick={() => setFilter(filter === tier ? 'все' : tier)}
                className={cx('rounded-2xl border p-4 text-left transition-all', filter === tier && 'ring-2 ring-[#10B981]/40')}
                style={{ borderColor: `${TIER_COLOR[tier]}55`, background: `${TIER_COLOR[tier]}12` }}>
                <p className="text-[12px] font-medium" style={{ color: TIER_COLOR[tier] }}>{tierLabels[tier]}</p>
                <p className="num mt-2 text-2xl font-semibold">{list.length}</p>
                <p className="num mt-1 text-[11px] text-slate-400">
                  {t.avgScorePrefix} {list.length ? Math.round(list.reduce((x, s) => x + s.predicted, 0) / list.length) : 0}
                </p>
              </button>
            );
          })}
        </div>

        <div className="grid gap-4 lg:grid-cols-[1.4fr_1fr]">
          <Card className="p-0">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#1F2937] px-5 py-3.5">
              <p className="text-[15px] font-semibold">{t.students}</p>
              <div className="flex items-center gap-2">
                {filter !== 'все' && <Btn size="sm" variant="soft" onClick={() => setFilter('все')}>{t.reset}</Btn>}
                <Sel className="h-9 w-auto py-0 text-xs" value={sort} onChange={(e) => setSort(e.target.value)}>
                  <option value="score">{t.sortScore}</option>
                  <option value="acc">{t.sortAcc}</option>
                  <option value="name">{t.sortName}</option>
                </Sel>
              </div>
            </div>
            <div className="divide-y divide-[#1F2937]">
              {rows.map((s) => {
                const weak = Object.entries(s.mastery)
                  .filter(([id]) => allTopics.some((item) => item.id === id))
                  .sort((a, b) => a[1] - b[1]).slice(0, 3);
                return (
                  <div key={s.id}>
                    <button onClick={() => setOpen(open === s.id ? null : s.id)}
                      className="flex w-full items-center gap-3 px-5 py-3.5 text-left transition-colors hover:bg-[#0F1622]">
                      <span className="h-8 w-1 shrink-0 rounded-full" style={{ background: TIER_COLOR[s.tier] }} />
                      <span className="min-w-0 flex-1">
                        <span className="flex items-center gap-2">
                          <span className="truncate text-[13px] font-medium">{s.name}</span>
                          {s.id.startsWith('stu-') && <Badge color="#2DD4BF">{t.liveBadge}</Badge>}
                        </span>
                        <span className="num mt-0.5 block truncate text-[11px] text-slate-500">
                          {s.grade} {t.gradeShort} · {localizeSchool(s.school, lang)}
                        </span>
                      </span>
                      <span className="hidden w-24 shrink-0 sm:block">
                        <Bar value={s.accuracy} />
                        <span className="num mt-1 block text-[10px] text-slate-500">{t.accuracyPrefix} {Math.round(s.accuracy * 100)}%</span>
                      </span>
                      <span className="num w-12 shrink-0 text-right text-lg font-semibold">{s.predicted}</span>
                      <span className="text-slate-500">{open === s.id ? '▲' : '▼'}</span>
                    </button>
                    {open === s.id && (
                      <div className="animate-up space-y-3 bg-[#0F1622] px-5 py-4">
                        <div className="flex flex-wrap gap-2">
                          <Badge>{localizeRegion(s.region, lang)}</Badge>
                          <Badge>{s.attempts} {t.attempts}</Badge>
                          <Badge>{s.subjects.map((x) => { const sub = SUBJECTS.find((y) => y.id === x); return sub ? localizeSubject(sub, lang).title : x; }).join(' + ')}</Badge>
                        </div>
                        {weak.map(([id, v]) => (
                          <div key={id}>
                            <div className="flex justify-between text-[12px]">
                              <span>{(() => { const tp = allTopics.find((item) => item.id === id); return tp ? localizeTopic(tp, lang).title : id; })()}</span>
                              <span className="num text-slate-400">{Math.round(v * 100)}%</span>
                            </div>
                            <div className="mt-1.5"><Bar value={v} /></div>
                          </div>
                        ))}
                        <div className="rounded-xl border border-[#1F2937] bg-[#111826] p-3.5">
                          <p className="text-[12px] font-medium">{t.recSys}</p>
                          <p className="mt-1.5 text-[12px] leading-relaxed text-slate-400">
                            {(() => {
                              const tp = allTopics.find((item) => item.id === weak[0]?.[0]);
                              const lt = tp ? localizeTopic(tp, lang) : null;
                              return <>
                                {t.startWith} «{lt?.title ?? ''}»: {lt?.theory.steps[0] ?? ''}. {t.control}: {lt?.theory.mistake ?? ''}
                              </>;
                            })()}
                          </p>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </Card>

          <Card>
            <p className="text-[15px] font-semibold">{t.problemTopics}</p>
            <p className="mt-1.5 text-[12px] text-slate-500">{t.problemSub}</p>
            <div className="mt-4 space-y-3">
              {problems.slice(0, 8).map((p) => (
                <div key={p.topic.id}>
                  <div className="flex justify-between gap-3 text-[12px]">
                    <span className="truncate text-slate-300">{localizeTopic(p.topic, lang).title}</span>
                    <span className="num shrink-0 text-slate-400">{Math.round(p.avg * 100)}%</span>
                  </div>
                  <div className="mt-1.5"><Bar value={p.avg} /></div>
                  <p className="num mt-1 text-[10px] text-slate-500">{t.belowThreshold} {p.below} {t.studentsCount}</p>
                </div>
              ))}
            </div>
          </Card>
        </div>

        <Card>
          <p className="text-[15px] font-semibold">{t.manageTitle}</p>
          {realStudents.length === 0 ? (
            <p className="mt-2 text-[12px] text-slate-500">{t.noRealStudents}</p>
          ) : (
            <div className="mt-3 divide-y divide-[#1F2937]">
              {realStudents.map((rs) => (
                <div key={rs.id} className="flex items-center justify-between gap-3 py-2.5">
                  <div className="min-w-0">
                    <p className="truncate text-[13px] font-medium">{rs.name}</p>
                    <p className="num text-[11px] text-slate-500">{rs.grade} {t.gradeShort} · {t.avgScorePrefix} {rs.predicted}</p>
                  </div>
                  <Btn size="sm" variant="ghost" onClick={() => handleDeleteStudent(rs.id)}>{t.deleteBtn}</Btn>
                </div>
              ))}
            </div>
          )}

          <div className="mt-5 border-t border-[#1F2937] pt-4">
            <p className="num text-[11px] uppercase tracking-widest text-slate-500">{t.addStudentTitle}</p>
            <form onSubmit={handleAddStudent} className="mt-3 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
              <Field label={t.fieldName}>
                <Input value={newName} onChange={(e) => setNewName(e.target.value)} maxLength={60} />
              </Field>
              <Field label={t.fieldGrade}>
                <Sel value={newGrade} onChange={(e) => setNewGrade(Number(e.target.value))}>
                  {[7, 8, 9, 10, 11, 12].map((g) => <option key={g} value={g}>{g}</option>)}
                </Sel>
              </Field>
              <Field label={t.fieldLogin}>
                <Input value={newLogin} onChange={(e) => setNewLogin(e.target.value)} maxLength={40} />
              </Field>
              <Field label={t.fieldPassword}>
                <Input value={newPassword} onChange={(e) => setNewPassword(e.target.value)} maxLength={40} />
              </Field>
              <div className="sm:col-span-2 lg:col-span-4">
                {addError && <p className="mb-2 text-[12px] text-[#F43F5E]">{addError}</p>}
                <Btn type="submit" disabled={addBusy}>{addBusy ? '…' : t.addStudentBtn}</Btn>
              </div>
            </form>
          </div>
        </Card>

        <Card>
          <p className="text-[15px] font-semibold">{t.moduleBuilder}</p>
          <p className="mt-1.5 text-[12px] text-slate-500">
            {t.builderSub}
          </p>
          {flash && <p className="mt-4 rounded-xl border border-[#10B981]/40 bg-[#10B981]/8 px-3.5 py-2.5 text-[12px] text-[#10B981]">{flash}</p>}

          <div className="mt-5 grid gap-6 lg:grid-cols-2">
            <div className="space-y-4">
              <p className="num text-[11px] uppercase tracking-widest text-slate-500">{t.newTopic}</p>
              <Field label={t.topicName}>
                <Input value={tTitle} onChange={(e) => setTTitle(e.target.value)} placeholder={t.topicPlaceholder} maxLength={80} />
              </Field>
              <div className="grid gap-3 sm:grid-cols-2">
                <Field label={t.subject}>
                  <Sel value={tSubject} onChange={(e) => setTSubject(e.target.value as SubjectId)}>
                    {SUBJECTS.map((s) => <option key={s.id} value={s.id}>{localizeSubject(s, lang).title}</option>)}
                  </Sel>
                </Field>
                <Field label={`${t.entWeight} ${tWeight.toFixed(2)}`}>
                  <input type="range" min={0.05} max={0.5} step={0.01} value={tWeight}
                    onChange={(e) => setTWeight(Number(e.target.value))} className="w-full" />
                </Field>
              </div>
              <Btn onClick={addTopic}>{t.addTopicBtn}</Btn>
            </div>

            <div className="space-y-4">
              <p className="num text-[11px] uppercase tracking-widest text-slate-500">{t.newItem}</p>
              <Field label={t.topicLabel}>
                <Sel value={iTopic} onChange={(e) => setITopic(e.target.value)}>
                  {allTopics.map((item) => <option key={item.id} value={item.id}>{localizeTopic(item, lang).title}</option>)}
                </Sel>
              </Field>
              <Field label={t.stemLabel}>
                <Input value={iStem} onChange={(e) => setIStem(e.target.value)} placeholder={t.stemPlaceholder} maxLength={220} />
              </Field>
              <Field label={t.optionsLabel} hint={t.optionsHint}>
                <div className="grid gap-2">
                  {iOpts.map((o, i) => (
                    <div key={i} className="flex items-center gap-2">
                      <input type="radio" checked={iAns === i} onChange={() => setIAns(i)} />
                      <Input value={o} placeholder={`${t.optPlaceholder} ${String.fromCharCode(65 + i)}`} maxLength={80}
                        onChange={(e) => setIOpts((p) => p.map((x, k) => (k === i ? e.target.value : x)))} />
                    </div>
                  ))}
                </div>
              </Field>
              <Field label={t.explainLabel}>
                <Input value={iExp} onChange={(e) => setIExp(e.target.value)} placeholder={t.explainPlaceholder} maxLength={220} />
              </Field>
              <Btn onClick={addItem}>{t.addItemBtn}</Btn>
            </div>
          </div>
        </Card>
      </div>
    </Shell>
  );
}