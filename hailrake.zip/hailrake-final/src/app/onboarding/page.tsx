'use client';
import { useRouter } from 'next/navigation';
import { useLanguage } from '@/context/LanguageContext';
import { useState } from 'react';
import { REGIONS, SUBJECTS, type SubjectId } from '@/lib/data';
import { localizeRegion, localizeSubject } from '@/lib/content';
import { useStore } from '@/lib/state';
import { Btn, Card, Field, Input, Sel, Shell, Title, cx } from '@/components/ui';


const dict = {
  ru: {
    eyebrow: 'Шаг 1 из 2',
    title: 'Профиль ученика',
    sub: 'Профиль задаёт веса в прогнозе балла ЕНТ и бюджет времени в индивидуальном плане.',
    nameLabel: 'Имя и фамилия',
    namePlaceholder: 'Айгерим Сәдуақас',
    gradeLabel: 'Класс',
    gradeSuffix: 'класс',
    regionLabel: 'Регион',
    schoolLabel: 'Школа',
    schoolPlaceholder: 'СШ №4, с. Мерке',
    teacherCodeLabel: 'Код класса (необязательно)',
    teacherCodePlaceholder: 'Код, который дал учитель',
    subjectsLabel: 'Профильные предметы ЕНТ (ровно 2)',
    subjectsHint: 'История Казахстана добавляется автоматически как обязательный блок экзамена.',
    goalLabel: 'Цель подготовки',
    goals: [
      { id: 'ЕНТ', title: 'ЕНТ', desc: 'Максимум по структуре 140 баллов' },
      { id: 'Олимпиада', title: 'Олимпиада', desc: 'Задания повышенной сложности' },
      { id: 'Закрыть пробелы', title: 'Закрыть пробелы', desc: 'Фокус на темах ниже 50%' },
    ],
    targetLabel: (t: number) => `Целевой балл: ${t} / 140`,
    examDateLabel: 'Дата ЕНТ',
    minutesLabel: 'Минут в день',
    minSuffix: 'мин',
    submitBtn: 'Перейти к диагностике →',
    errName: 'Укажите имя (минимум 2 символа).',
    errSubjects: 'Выберите ровно два профильных предмета.',
    errSchool: 'Укажите школу — она нужна панели учителя.',
    haveLogin: 'Уже есть логин от учителя? Войти →',
  },
  kz: {
    eyebrow: '1-ші қадам (2-ден)',
    title: 'Оқушы профилі',
    sub: 'Профиль ҰБТ балын болжаудағы салмақтарды және жеке жоспардағы уақыт бюджемін белгілейді.',
    nameLabel: 'Аты-жөні',
    namePlaceholder: 'Айгерим Сәдуақас',
    gradeLabel: 'Сынып',
    gradeSuffix: 'сынып',
    regionLabel: 'Өңір',
    schoolLabel: 'Мектеп',
    schoolPlaceholder: '№4 ОМ, Меркі ауылы',
    teacherCodeLabel: 'Сынып коды (міндетті емес)',
    teacherCodePlaceholder: 'Мұғалім берген код',
    subjectsLabel: 'ҰБТ бейіндік пәндері (дәл 2 пән)',
    subjectsHint: 'Қазақстан тарихы міндетті емтихан блок ретінде автоматты түрде қосылады.',
    goalLabel: 'Дайындық мақсаты',
    goals: [
      { id: 'ЕНТ', title: 'ҰБТ', desc: 'Құрылым бойынша максимум 140 балл' },
      { id: 'Олимпиада', title: 'Олимпиада', desc: 'Қиындығы жоғары тапсырмалар' },
      { id: 'Закрыть пробелы', title: 'Олқылықтарды толтыру', desc: '50%-дан төмен тақырыптарға назар аудару' },
    ],
    targetLabel: (t: number) => `Мақсатты балл: ${t} / 140`,
    examDateLabel: 'ҰБТ күні',
    minutesLabel: 'Күніне минут',
    minSuffix: 'мин',
    submitBtn: 'Диагностикаға өту →',
    errName: 'Атыңызды көрсетіңіз (кемінде 2 таңба).',
    errSubjects: 'Дәл екі бейіндік пәнді таңдаңыз.',
    errSchool: 'Мектепті көрсетіңіз — бұл мұғалім панеліне қажет.',
    haveLogin: 'Мұғалімнен логин бар ма? Кіру →',
  },
  en: {
    eyebrow: 'Step 1 of 2',
    title: 'Student Profile',
    sub: 'The profile sets weights for the ENT score forecast and time budget in your individual plan.',
    nameLabel: 'Full Name',
    namePlaceholder: 'Aigerim Saduakas',
    gradeLabel: 'Grade',
    gradeSuffix: 'grade',
    regionLabel: 'Region',
    schoolLabel: 'School',
    schoolPlaceholder: 'School №4, Merke',
    teacherCodeLabel: 'Class code (optional)',
    teacherCodePlaceholder: 'The code your teacher gave you',
    subjectsLabel: 'ENT Profile Subjects (exactly 2)',
    subjectsHint: 'History of Kazakhstan is added automatically as a mandatory exam block.',
    goalLabel: 'Preparation Goal',
    goals: [
      { id: 'ЕНТ', title: 'ENT', desc: 'Maximum score structure of 140 points' },
      { id: 'Олимпиада', title: 'Olympiad', desc: 'Advanced difficulty tasks' },
      { id: 'Закрыть пробелы', title: 'Fill Gaps', desc: 'Focus on topics below 50%' },
    ],
    targetLabel: (t: number) => `Target Score: ${t} / 140`,
    examDateLabel: 'ENT Date',
    minutesLabel: 'Minutes per day',
    minSuffix: 'min',
    submitBtn: 'Proceed to Diagnostics →',
    errName: 'Please enter your name (at least 2 characters).',
    errSubjects: 'Please select exactly two profile subjects.',
    errSchool: 'Please specify your school — required for the teacher panel.',
    haveLogin: 'Already have a login from your teacher? Log in →',
  },
};

export default function Onboarding() {
  const r = useRouter();
  const { profile, saveProfile } = useStore();
  const { lang } = useLanguage();
  const t = dict[lang];

  const [name, setName] = useState(profile?.name ?? '');
  const [grade, setGrade] = useState(profile?.grade ?? 11);
  const [region, setRegion] = useState(profile?.region ?? REGIONS[0]);
  const [school, setSchool] = useState(profile?.school ?? '');
  const [subjects, setSubjects] = useState<SubjectId[]>(profile?.subjects ?? ['math', 'physics']);
  const [goal, setGoal] = useState(profile?.goal ?? 'ЕНТ');
  const [target, setTarget] = useState(profile?.target ?? 110);
  const [examDate, setExamDate] = useState(profile?.examDate ?? '2027-06-20');
  const [minutesPerDay, setMinutes] = useState(profile?.minutesPerDay ?? 45);
  const [teacherCode, setTeacherCode] = useState(profile?.teacherCode ?? '');
  const [err, setErr] = useState('');

  const toggle = (id: SubjectId) =>
    setSubjects((p) => (p.includes(id) ? p.filter((s) => s !== id) : p.length >= 2 ? [p[1], id] : [...p, id]));

  const submit = () => {
    if (name.trim().length < 2) return setErr(t.errName);
    if (subjects.length !== 2) return setErr(t.errSubjects);
    if (school.trim().length < 2) return setErr(t.errSchool);
    setErr('');
    saveProfile({
      id: profile?.id ?? `stu-${crypto.randomUUID()}`,
      name: name.trim(), grade, region, school: school.trim(),
      subjects, goal, target, examDate, minutesPerDay,
      teacherCode: teacherCode.trim() || undefined,
    });
    r.push('/diagnostic');
  };

  return (
    <Shell>
      <div className="wrap max-w-3xl py-10">
        <div className="flex items-center justify-between gap-4 mb-2">
          <Title eyebrow={t.eyebrow} title={t.title} sub={t.sub} />
          <button onClick={() => r.push('/student-login')} className="shrink-0 text-[12px] text-slate-500 hover:text-slate-300">
            {t.haveLogin}
          </button>
        </div>

        <Card className="mt-8 space-y-6">
          <div className="grid gap-5 sm:grid-cols-2">
            <Field label={t.nameLabel}>
              <Input value={name} onChange={(e) => setName(e.target.value)} placeholder={t.namePlaceholder} maxLength={60} />
            </Field>
            <Field label={t.gradeLabel}>
              <Sel value={grade} onChange={(e) => setGrade(Number(e.target.value))}>
                {[7, 8, 9, 10, 11, 12].map((g) => <option key={g} value={g}>{g} {t.gradeSuffix}</option>)}
              </Sel>
            </Field>
            <Field label={t.regionLabel}>
              <Sel value={region} onChange={(e) => setRegion(e.target.value)}>
                {REGIONS.map((x) => <option key={x} value={x}>{localizeRegion(x, lang)}</option>)}
              </Sel>
            </Field>
            <Field label={t.schoolLabel}>
              <Input value={school} onChange={(e) => setSchool(e.target.value)} placeholder={t.schoolPlaceholder} maxLength={80} />
            </Field>
            <Field label={t.teacherCodeLabel}>
              <Input value={teacherCode} onChange={(e) => setTeacherCode(e.target.value)} placeholder={t.teacherCodePlaceholder} maxLength={40} />
            </Field>
          </div>

          <Field label={t.subjectsLabel} hint={t.subjectsHint}>
            <div className="flex flex-wrap gap-2">
              {SUBJECTS.map((s) => (
                <button key={s.id} type="button" onClick={() => toggle(s.id)}
                  className={cx('rounded-xl border px-3.5 py-2.5 text-sm transition-all',
                    subjects.includes(s.id) ? 'border-[#10B981]/60 bg-[#10B981]/12 text-[#10B981]'
                      : 'border-[#1F2937] text-slate-400 hover:text-slate-100')}>
                  {subjects.includes(s.id) ? '✓ ' : ''}{localizeSubject(s, lang).title}
                </button>
              ))}
            </div>
          </Field>

          <Field label={t.goalLabel}>
            <div className="grid gap-2 sm:grid-cols-3">
              {t.goals.map((item) => (
                <button key={item.id} type="button" onClick={() => setGoal(item.id)}
                  className={cx('rounded-xl border p-3.5 text-left transition-all',
                    goal === item.id ? 'border-[#10B981]/60 bg-[#10B981]/8' : 'border-[#1F2937] hover:border-[#10B981]/30')}>
                  <p className="text-[13px] font-medium">{item.title}</p>
                  <p className="mt-1 text-[11px] leading-relaxed text-slate-500">{item.desc}</p>
                </button>
              ))}
            </div>
          </Field>

          <div className="grid gap-5 sm:grid-cols-3">
            <Field label={t.targetLabel(target)}>
              <input type="range" min={60} max={140} step={5} value={target}
                onChange={(e) => setTarget(Number(e.target.value))} className="w-full" />
            </Field>
            <Field label={t.examDateLabel}>
              <Input type="date" value={examDate} onChange={(e) => setExamDate(e.target.value)} />
            </Field>
            <Field label={t.minutesLabel}>
              <Sel value={minutesPerDay} onChange={(e) => setMinutes(Number(e.target.value))}>
                {[20, 30, 45, 60, 90, 120].map((m) => <option key={m} value={m}>{m} {t.minSuffix}</option>)}
              </Sel>
            </Field>
          </div>

          {err && <p className="rounded-xl border border-[#F43F5E]/40 bg-[#F43F5E]/10 px-3.5 py-2.5 text-[13px] text-[#F43F5E]">{err}</p>}

          <div className="flex justify-end border-t border-[#1F2937] pt-5">
            <Btn onClick={submit}>{t.submitBtn}</Btn>
          </div>
        </Card>
      </div>
    </Shell>
  );
}
