'use client';
import { useLanguage } from '@/context/LanguageContext';
import { useRouter } from 'next/navigation';
import { ITEMS, TOPICS } from '@/lib/data';
import { forecast } from '@/lib/engine';
import { localizeConfidence } from '@/lib/content';
import { useStore } from '@/lib/state';
import { Badge, Bar, Btn, Card, Gauge } from '@/components/ui';

const YEARS = ['2021', '2022', '2023', '2024', '2025', '2026'];
const STRONG = [112, 114, 115, 117, 118, 120];
const RURAL = [61, 60, 63, 62, 64, 65];
const HAIL = [61, 60, 63, 74, 92, 111];


const dict = {
  ru: {
    continue: 'Продолжить',
    start: 'Начать',
    badge: 'AI-платформа подготовки к ЕНТ · Казахстан',
    title: 'Персональный ИИ-репетитор для каждого ученика Казахстана',
    desc: 'Платформа измеряет реальный уровень знаний по психометрической модели IRT, находит пробелы до уровня отдельного навыка и строит индивидуальную траекторию до целевого балла ЕНТ — независимо от школы и региона.',
    startTrain: 'Начать обучение',
    diag: 'Пройти диагностику',
    stat1: 'тем в адаптивном ядре',
    stat2: 'заданий с разбором',
    stat3: 'минут до личного плана',
    predScore: 'Твой прогнозируемый балл ЕНТ',
    maxScore: '140 макс.',
    interval: 'интервал',
    dataConfidence: 'полнота данных:',
    demo: 'демо',
    diagNote1: 'Балл пересчитывается после каждого задания — прогноз построен на твоих ответах.',
    diagNote2: 'Это демонстрационный прогноз. Пройди диагностику — балл пересчитается по твоим ответам.',
    gapTitle: 'Мы сокращаем образовательный разрыв',
    gapDesc: 'Средний балл ЕНТ: сильные городские школы против сельских. Зелёная линия — траектория ученика, занимающегося с Hailrake AI.',
    strongSchools: 'Сильные школы',
    ruralSchools: 'Сельская школа',
    withHailrake: 'С Hailrake AI',
    m1Val: '+46',
    m1Desc: 'балла — прирост траектории',
    m2Val: '11',
    m2Desc: 'недель до выхода из зоны риска',
    m3Val: '0 ₸',
    m3Desc: 'стоимость для ученика',
    card1Title: 'Для учеников',
    card1Desc: 'Диагностика находит пробелы, платформа подбирает задания в зоне роста и объясняет каждую ошибку.',
    card2Title: 'Для учителей',
    card2Desc: 'Панель показывает класс по зонам риска и ранжирует проблемные темы. Новые модули добавляются без разработки.',
    card3Title: 'Для регионов',
    card3Desc: 'Работает на любом телефоне, не требует репетитора и стабильного города вокруг.',
  },
  kz: {
    continue: 'Жалғастыру',
    start: 'Бастау',
    badge: 'ҰБТ-ға дайындық AI-платформасы · Қазақстан',
    title: 'Қазақстанның әрбір оқушысына арналған жеке AI-репетитор',
    desc: 'Платформа IRT психометрикалық моделі арқылы нақты білім деңгейін өлшейді, жеке дағды деңгейіндегі олқылықтарды тауып, мектеп пен аймаққа тәуелсіз ҰБТ мақсатты балына дейінгі жеке траекторияны құрады.',
    startTrain: 'Оқуды бастау',
    diag: 'Диагностикадан өту',
    stat1: 'бейімдеу ядросындағы тақырып',
    stat2: 'талдауы бар тапсырма',
    stat3: 'жеке жоспарға дейін минут',
    predScore: 'Сіздің болжамды ҰБТ балыңыз',
    maxScore: '140 макс.',
    interval: 'аралық',
    dataConfidence: 'деректер толықтығы:',
    demo: 'демо',
    diagNote1: 'Балл әр тапсырмадан кейін қайта есептеледі — болжам сіздің жауаптарыңызға негізделген.',
    diagNote2: 'Бұл көрсеткіштік болжам. Диагностикадан өтіңіз — балл жауаптарыңыз бойынша қайта есептеледі.',
    gapTitle: 'Біз білім беру алшақтығын қысқартамыз',
    gapDesc: 'ҰБТ орташа балы: мықты қала мектептері ауыл мектептеріне қарсы. Жасыл сызық — Hailrake AI арқылы дайындалып жатқан оқушының траекториясы.',
    strongSchools: 'Мықты мектептер',
    ruralSchools: 'Ауыл мектебі',
    withHailrake: 'Hailrake AI-мен',
    m1Val: '+46',
    m1Desc: 'балл — траектория өсімі',
    m2Val: '11',
    m2Desc: 'апта қауіп аймағынан шығуға',
    m3Val: '0 ₸',
    m3Desc: 'оқушы үшін құны',
    card1Title: 'Оқушылар үшін',
    card1Desc: 'Диагностика олқылықтарды табады, платформа өсу аймағындағы тапсырмаларды таңдап, әр қатені түсіндіреді.',
    card2Title: 'Мұғалімдер үшін',
    card2Desc: 'Панель сыныпты қауіп аймақтары бойынша көрсетеді және проблемалық тақырыптарды реттейді.',
    card3Title: 'Аймақтар үшін',
    card3Desc: 'Кез келген телефонда жұмыс істейді, репетиторды қажет етпейді.',
  },
  en: {
    continue: 'Continue',
    start: 'Start',
    badge: 'ENT Prep AI Platform · Kazakhstan',
    title: 'Personal AI Tutor for Every Student in Kazakhstan',
    desc: 'The platform measures real knowledge levels using the IRT psychometric model, identifies skill gaps, and builds an individual learning path to the target ENT score.',
    startTrain: 'Start Learning',
    diag: 'Take Diagnostic',
    stat1: 'topics in adaptive core',
    stat2: 'parsed assignments',
    stat3: 'minutes to personal plan',
    predScore: 'Your Predicted ENT Score',
    maxScore: '140 max',
    interval: 'interval',
    dataConfidence: 'data confidence:',
    demo: 'demo',
    diagNote1: 'Score updates after each task — forecast is based on your answers.',
    diagNote2: 'This is a demo forecast. Take the diagnostic to update your score.',
    gapTitle: 'Bridging the Educational Gap',
    gapDesc: 'Average ENT scores: strong urban schools vs. rural schools. The green line represents a student studying with Hailrake AI.',
    strongSchools: 'Strong Schools',
    ruralSchools: 'Rural School',
    withHailrake: 'With Hailrake AI',
    m1Val: '+46',
    m1Desc: 'score trajectory growth',
    m2Val: '11',
    m2Desc: 'weeks out of risk zone',
    m3Val: '0 ₸',
    m3Desc: 'cost for the student',
    card1Title: 'For Students',
    card1Desc: 'Diagnostics find gaps, the platform selects tasks in your growth zone and explains every mistake.',
    card2Title: 'For Teachers',
    card2Desc: 'The dashboard shows classes by risk zones and prioritizes problem areas.',
    card3Title: 'For Regions',
    card3Desc: 'Works on any mobile phone without requiring an expensive tutor.',
  },
};

export default function Home() {
  const r = useRouter();
  const { lang } = useLanguage();
  const t = dict[lang];

  const { loaded, profile, mastery, attemptsByTopic, customTopics, diagDone } = useStore();

  const f = profile
    ? forecast(profile.subjects, mastery, attemptsByTopic, customTopics, profile.target)
    : { predicted: 118, low: 109, high: 127, target: 140, confidence: t.demo };

  const W = 700, H = 240, P = 32;
  const x = (i: number) => P + (i * (W - P * 2)) / 5;
  const y = (v: number) => H - P - ((v - 45) / 85) * (H - P * 2);
  const path = (a: number[]) => a.map((v, i) => `${i ? 'L' : 'M'}${x(i)},${y(v)}`).join(' ');

  return (
    <div>
      <header className="border-b border-[#1F2937]">
        <div className="wrap flex h-16 items-center justify-between">
          <div className="flex items-center gap-2.5">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-[#10B981]/15 text-[#10B981]">
              <span className="num text-sm font-bold">H</span>
            </span>
            <span className="text-[15px] font-semibold">Hailrake AI</span>
          </div>

          <div className="flex items-center gap-4">
            <Btn size="sm" onClick={() => r.push(profile ? '/dashboard' : '/onboarding')}>
              {profile ? t.continue : t.start}
            </Btn>
          </div>
        </div>
      </header>

      <section className="relative overflow-hidden">
        <div className="glow pointer-events-none absolute inset-0" />
        <div className="wrap relative grid gap-10 py-16 lg:grid-cols-[1.1fr_1fr] lg:items-center lg:py-24">
          <div>
            <Badge color="#10B981">{t.badge}</Badge>
            <h1 className="mt-6 text-[32px] font-semibold leading-[1.12] tracking-tight sm:text-5xl">
              {t.title}
            </h1>
            <p className="mt-5 max-w-xl text-[15px] leading-relaxed text-slate-400">
              {t.desc}
            </p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <Btn onClick={() => r.push(profile ? '/dashboard' : '/onboarding')}>
                {profile ? t.continue : t.startTrain} →
              </Btn>
              <Btn variant="ghost" onClick={() => r.push('/diagnostic')}>{t.diag}</Btn>
            </div>
            <div className="mt-12 grid max-w-lg grid-cols-3 gap-6 border-t border-[#1F2937] pt-7">
              {[
                [String(TOPICS.length), t.stat1],
                [String(ITEMS.length), t.stat2],
                ['6', t.stat3],
              ].map(([v, l]) => (
                <div key={l}>
                  <p className="num text-3xl font-semibold">{v}</p>
                  <p className="mt-1 text-xs leading-relaxed text-slate-500">{l}</p>
                </div>
              ))}
            </div>
          </div>

          <Card className="animate-up">
            <div className="flex items-center justify-between">
              <p className="text-[13px] font-semibold">{t.predScore}</p>
              <Badge color="#8B5CF6">{t.maxScore}</Badge>
            </div>
            <div className="my-6 flex justify-center">
              {loaded ? <Gauge value={f.predicted / f.target} predicted={f.predicted} target={f.target} />
                : <div className="h-[172px] w-[172px] animate-pulse rounded-full bg-[#1F2937]" />}
            </div>
            <Bar value={f.predicted / f.target} />
            <div className="num mt-3 flex justify-between text-[11px] text-slate-500">
              <span>{t.interval} {f.low}–{f.high}</span>
              <span>{t.dataConfidence} {localizeConfidence(f.confidence, lang)}</span>
            </div>
            <p className="mt-4 text-[12px] leading-relaxed text-slate-400">
              {diagDone ? t.diagNote1 : t.diagNote2}
            </p>
            <Btn className="mt-5 w-full" onClick={() => r.push('/diagnostic')}>{t.diag}</Btn>
          </Card>
        </div>
      </section>

      <section className="wrap pb-20">
        <Card>
          <h2 className="text-xl font-semibold sm:text-2xl">{t.gapTitle}</h2>
          <p className="mt-2 max-w-2xl text-sm leading-relaxed text-slate-400">
            {t.gapDesc}
          </p>
          <div className="mt-5 flex flex-wrap gap-4 text-[11px] text-slate-400">
            {[
              ['#94A3B8', t.strongSchools], 
              ['#F43F5E', t.ruralSchools], 
              ['#10B981', t.withHailrake]
            ].map(([c, l]) => (
              <span key={l} className="flex items-center gap-2">
                <i className="h-1.5 w-5 rounded-full" style={{ background: c }} />{l}
              </span>
            ))}
          </div>
          <svg viewBox={`0 0 ${W} ${H}`} className="mt-4 w-full">
            {[45, 70, 95, 120].map((v) => (
              <g key={v}>
                <line x1={P} x2={W - P} y1={y(v)} y2={y(v)} stroke="#1F2937" />
                <text x="2" y={y(v) + 3} fontSize="9" fill="#64748B">{v}</text>
              </g>
            ))}
            {YEARS.map((yr, i) => (
              <text key={yr} x={x(i)} y={H - 8} fontSize="9" textAnchor="middle" fill="#64748B">{yr}</text>
            ))}
            <path d={`${path(STRONG)} L${x(5)},${y(RURAL[5])} ${RURAL.slice().reverse().map((v, i) => `L${x(5 - i)},${y(v)}`).join(' ')} Z`}
              fill="rgba(244,63,94,.12)" />
            <path d={path(STRONG)} fill="none" stroke="#94A3B8" strokeWidth="2" strokeDasharray="5 5" />
            <path d={path(RURAL)} fill="none" stroke="#F43F5E" strokeWidth="2.5" />
            <path d={path(HAIL)} fill="none" stroke="#10B981" strokeWidth="3" />
            {HAIL.map((v, i) => <circle key={i} cx={x(i)} cy={y(v)} r="3.5" fill="#10B981" />)}
          </svg>
          <div className="mt-5 grid gap-4 border-t border-[#1F2937] pt-5 sm:grid-cols-3">
            {[
              [t.m1Val, t.m1Desc], 
              [t.m2Val, t.m2Desc], 
              [t.m3Val, t.m3Desc]
            ].map(([k, l]) => (
              <div key={l}>
                <p className="num text-2xl font-semibold text-[#10B981]">{k}</p>
                <p className="text-xs text-slate-500">{l}</p>
              </div>
            ))}
          </div>
        </Card>

        <div className="mt-4 grid gap-4 sm:grid-cols-3">
          {[
            [t.card1Title, t.card1Desc],
            [t.card2Title, t.card2Desc],
            [t.card3Title, t.card3Desc],
          ].map(([title, desc]) => (
            <Card key={title}>
              <p className="text-[15px] font-semibold">{title}</p>
              <p className="mt-2 text-[13px] leading-relaxed text-slate-400">{desc}</p>
            </Card>
          ))}
        </div>
      </section>
    </div>
  );
}