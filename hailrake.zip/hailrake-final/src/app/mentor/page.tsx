'use client';
import { useEffect, useMemo, useRef, useState } from 'react';
import { useLanguage } from '@/context/LanguageContext';
import { TOPICS } from '@/lib/data';
import { localizeTopic } from '@/lib/content';
import { relevantTopics } from '@/lib/engine';
import { useStore, type Msg } from '@/lib/state';
import { Badge, Btn, Card, Sel, Shell, Title, cx } from '@/components/ui';


const dict = {
  ru: {
    eyebrow: 'AI-модуль',
    title: 'ИИ-ментор',
    sub: 'Академический режим: только темы ЕНТ. Ненормативная лексика, офтоп и попытки изменить инструкции блокируются на входе.',
    botName: 'Hailrake Mentor',
    noTopic: 'тема не выбрана',
    clearBtn: 'Очистить',
    quickPrompts: [
      'Объясни алгоритм решения квадратных неравенств',
      'Разбери типичные ошибки в законах Ньютона',
      'Как запомнить даты Казахского ханства?',
      'Составь план подготовки на неделю',
    ],
    thinking: 'Ментор формирует ответ…',
    placeholder: 'Вопрос по теме ЕНТ…',
    sendBtn: 'Отправить',
    contextTitle: 'Контекст ответа',
    noTopicOption: 'Тема не выбрана',
    masteryLabel: (p: number) => `Освоение темы ${p}% — глубина объяснения подстраивается автоматически.`,
    weakTopicsTitle: 'Ваши слабые темы',
    noWeakTopics: 'Слабых тем не выявлено.',
    weakTopicsHint: 'Передаются в промпт как контекст ученика — ментор закрывает именно эти пробелы.',
    netError: 'Сетевая ошибка. Повторите запрос.',
    defaultAnswer: 'Ответ не получен.',
    goalEnt: 'ЕНТ', goalOlympiad: 'Олимпиада', goalGaps: 'Закрыть пробелы',
    sourceLocal: 'локальный экспертный движок',
    sourceGemini: 'Gemini AI',
  },
  kz: {
    eyebrow: 'AI-модуль',
    title: 'ИИ-ментор',
    sub: 'Академиялық режим: тек ҰБТ тақырыптары. Боғауыз сөздер, офтоп және нұсқауларды өзгерту әрекеттері бұғатталады.',
    botName: 'Hailrake Mentor',
    noTopic: 'тақырып таңдалмаған',
    clearBtn: 'Тазарту',
    quickPrompts: [
      'Квадрат теңсіздіктерді шешу алгоритмін түсіндір',
      'Ньютон заңдарындағы жиі кездесетін қателерді талда',
      'Қазақ хандығының даталарын қалай есте сақтауға болады?',
      'Бір аптаға арналған дайындық жоспарын құр',
    ],
    thinking: 'Ментор жауап дайындауда…',
    placeholder: 'ҰБТ тақырыбы бойынша сұрақ…',
    sendBtn: 'Жіберу',
    contextTitle: 'Жауап контексті',
    noTopicOption: 'Тақырып таңдалмаған',
    masteryLabel: (p: number) => `Тақырыпты меңгеру ${p}% — түсіндіру тереңдігі автоматты түрде реттеледі.`,
    weakTopicsTitle: 'Сіздің әлсіз тақырыптарыңыз',
    noWeakTopics: 'Әлсіз тақырыптар анықталмады.',
    weakTopicsHint: 'Оқушы контексті ретінде промптқа беріледі — ментор дәл осы олқылықтарды жабады.',
    netError: 'Желі қатесі. Сұрауды қайталаңыз.',
    defaultAnswer: 'Жауап алынбады.',
    goalEnt: 'ҰБТ', goalOlympiad: 'Олимпиада', goalGaps: 'Олқылықтарды толтыру',
    sourceLocal: 'жергілікті сараптамалық жүйе',
    sourceGemini: 'Gemini AI',
  },
  en: {
    eyebrow: 'AI Module',
    title: 'AI Mentor',
    sub: 'Academic mode: ENT topics only. Profanity, off-topic chats, and prompt injection attempts are blocked.',
    botName: 'Hailrake Mentor',
    noTopic: 'no topic selected',
    clearBtn: 'Clear',
    quickPrompts: [
      'Explain the algorithm for solving quadratic inequalities',
      'Analyze common mistakes in Newton\'s laws',
      'How to memorize dates of the Kazakh Khanate?',
      'Create a weekly study plan',
    ],
    thinking: 'Mentor is generating response…',
    placeholder: 'Question on ENT topic…',
    sendBtn: 'Send',
    contextTitle: 'Response Context',
    noTopicOption: 'No topic selected',
    masteryLabel: (p: number) => `Topic mastery ${p}% — explanation depth adapts automatically.`,
    weakTopicsTitle: 'Your Weak Topics',
    noWeakTopics: 'No weak topics detected.',
    weakTopicsHint: 'Passed to the prompt as student context — the mentor closes exactly these gaps.',
    netError: 'Network error. Please try again.',
    defaultAnswer: 'No response received.',
    goalEnt: 'ENT', goalOlympiad: 'Olympiad', goalGaps: 'Close gaps',
    sourceLocal: 'local expert engine',
    sourceGemini: 'Gemini AI',
  },
};

function Rich({ text }: { text: string }) {
  return (
    <div className="space-y-2 text-[14px] leading-relaxed">
      {text.split('\n').map((raw, i) => {
        const l = raw.trim();
        if (!l) return <div key={i} className="h-1" />;
        if (l.startsWith('### ')) return <p key={i} className="font-semibold">{l.slice(4)}</p>;
        const parts = l.split(/(\*\*[^*]+\*\*)/g).map((p, j) =>
          p.startsWith('**') && p.endsWith('**')
            ? <strong key={j} className="font-semibold text-slate-100">{p.slice(2, -2)}</strong>
            : <span key={j}>{p}</span>);
        return <p key={i}>{parts}</p>;
      })}
    </div>
  );
}

export default function Mentor() {
  const st = useStore();
  const { lang } = useLanguage();
  const t = dict[lang];

  const [draft, setDraft] = useState('');
  const [busy, setBusy] = useState(false);
  const [topicId, setTopicId] = useState('');
  const endRef = useRef<HTMLDivElement>(null);

  const subjects = st.profile?.subjects ?? ['math', 'physics'];
  const topics = useMemo(() => relevantTopics(subjects, st.customTopics), [subjects, st.customTopics]);
  const topic = [...TOPICS, ...st.customTopics].find((item) => item.id === topicId) ?? null;

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [st.chat.length, busy]);

  const send = async (text: string) => {
    const message = text.trim();
    if (!message || busy) return;
    setDraft('');
    st.addMsg({ id: `u${Date.now()}`, role: 'user', text: message });
    setBusy(true);
    try {
      const res = await fetch('/api/tutor', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          message,
          context: {
            grade: st.profile?.grade,
            goal: st.profile?.goal === 'ЕНТ' ? t.goalEnt : st.profile?.goal === 'Олимпиада' ? t.goalOlympiad : st.profile?.goal === 'Закрыть пробелы' ? t.goalGaps : st.profile?.goal,
            topicId: topicId || undefined,
            topicTitle: topic?.title,
            mastery: topicId ? st.mastery[topicId] ?? 0.25 : undefined,
          },
        }),
      });
      const d = (await res.json()) as { answer?: string; hints?: string[]; source?: string; blocked?: boolean };
      st.addMsg({
        id: `a${Date.now()}`, role: 'ai',
        text: d.answer ?? t.defaultAnswer,
        hints: d.hints ?? [], source: d.source, blocked: d.blocked,
      });
    } catch {
      st.addMsg({ id: `e${Date.now()}`, role: 'ai', text: t.netError, source: 'local' });
    } finally {
      setBusy(false);
    }
  };

  const errors = useMemo(() => {
    const items = topics.filter((x) => (st.mastery[x.id] ?? 1) < 0.5).map((x) => localizeTopic(x, lang).title);
    return items.slice(0, 4);
  }, [topics, st.mastery, lang]);

  return (
    <Shell>
      <div className="wrap space-y-4 py-10">
        <div className="flex items-center justify-between gap-4">
          <Title eyebrow={t.eyebrow} title={t.title} sub={t.sub} />
        </div>

        <div className="grid gap-4 lg:grid-cols-[1fr_280px]">
          <Card className="flex h-[min(70vh,680px)] flex-col p-0">
            <div className="flex items-center justify-between border-b border-[#1F2937] px-5 py-3.5">
              <div>
                <p className="text-[13px] font-semibold">{t.botName}</p>
                <p className="text-[11px] text-slate-500">{topic ? localizeTopic(topic, lang).title : t.noTopic}</p>
              </div>
              {st.chat.length > 0 && <Btn size="sm" variant="soft" onClick={st.clearChat}>{t.clearBtn}</Btn>}
            </div>

            <div className="flex-1 space-y-4 overflow-y-auto px-5 py-5">
              {st.chat.length === 0 && (
                <div className="space-y-2">
                  {t.quickPrompts.map((q) => (
                    <button key={q} onClick={() => void send(q)}
                      className="w-full rounded-xl border border-[#1F2937] bg-[#0F1622] px-3.5 py-2.5 text-left text-[13px] text-slate-400 transition-colors hover:border-[#10B981]/50 hover:text-slate-100">
                      {q}
                    </button>
                  ))}
                </div>
              )}

              {st.chat.map((m: Msg) => (
                <div key={m.id} className={cx('flex', m.role === 'user' ? 'justify-end' : 'justify-start')}>
                  <div className={cx('max-w-[88%] rounded-2xl border px-4 py-3',
                    m.role === 'user' ? 'border-[#1F2937] bg-[#1F2937]'
                      : m.blocked ? 'border-[#F59E0B]/40 bg-[#F59E0B]/8' : 'border-[#1F2937] bg-[#0F1622]')}>
                    <Rich text={m.text} />
                    {m.hints && m.hints.length > 0 && (
                      <div className="mt-3 space-y-1.5 border-t border-[#1F2937] pt-3">
                        {m.hints.map((h, i) => <p key={i} className="text-[12px] text-slate-400">→ {h}</p>)}
                      </div>
                    )}
                    {m.role === 'ai' && m.source && (
                      <p className="num mt-2 text-[10px] uppercase tracking-wider text-slate-500">
                        {m.source === 'local' ? t.sourceLocal : m.source === 'Gemini AI' ? t.sourceGemini : m.source}
                      </p>
                    )}
                  </div>
                </div>
              ))}

              {busy && <p className="text-[13px] text-slate-500">{t.thinking}</p>}
              <div ref={endRef} />
            </div>

            <form onSubmit={(e) => { e.preventDefault(); void send(draft); }}
              className="flex items-end gap-2 border-t border-[#1F2937] p-4">
              <textarea value={draft} onChange={(e) => setDraft(e.target.value)} rows={1} maxLength={1000}
                onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); void send(draft); } }}
                placeholder={t.placeholder}
                className="max-h-28 min-h-[44px] flex-1 resize-none rounded-xl border border-[#1F2937] bg-[#0F1622] px-3.5 py-3 text-sm outline-none focus:border-[#10B981] placeholder:text-slate-500" />
              <Btn type="submit" disabled={busy || !draft.trim()}>{t.sendBtn}</Btn>
            </form>
          </Card>

          <div className="space-y-4">
            <Card>
              <p className="text-[13px] font-semibold">{t.contextTitle}</p>
              <div className="mt-3">
                <Sel value={topicId} onChange={(e) => setTopicId(e.target.value)}>
                  <option value="">{t.noTopicOption}</option>
                  {topics.map((item) => <option key={item.id} value={item.id}>{localizeTopic(item, lang).title}</option>)}
                </Sel>
              </div>
              {topic && (
                <p className="mt-3 text-[12px] leading-relaxed text-slate-400">
                  {t.masteryLabel(Math.round((st.mastery[topic.id] ?? 0) * 100))}
                </p>
              )}
            </Card>
            <Card>
              <p className="text-[13px] font-semibold">{t.weakTopicsTitle}</p>
              {errors.length === 0
                ? <p className="mt-2 text-[12px] text-slate-500">{t.noWeakTopics}</p>
                : <div className="mt-3 flex flex-wrap gap-1.5">
                    {errors.map((e) => <Badge key={e} color="#F59E0B">{e}</Badge>)}
                  </div>}
              <p className="mt-3 text-[11px] leading-relaxed text-slate-500">
                {t.weakTopicsHint}
              </p>
            </Card>
          </div>
        </div>
      </div>
    </Shell>
  );
}
