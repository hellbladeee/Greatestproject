'use client';
import { useRouter } from 'next/navigation';
import { useLanguage } from '@/context/LanguageContext';
import { useEffect, useMemo } from 'react';
import { localizeReason, localizeRegion, localizeSectionLabel, localizeTopic } from '@/lib/content';
import { forecast, relevantTopics, roadmap } from '@/lib/engine';
import { useStore } from '@/lib/state';
import { Badge, Bar, Btn, Card, Gauge, Radar, Shell, Spark, Stat, Title } from '@/components/ui';


const dict = {
  ru: {
    loading: 'Загрузка…',
    noProfileTitle: 'Профиль не создан',
    noProfileSub: 'Создайте профиль, чтобы платформа построила личную траекторию.',
    noProfileBtn: 'Создать профиль',
    logoutBtn: 'Выйти',
    diagWarningTitle: 'Диагностика не пройдена',
    diagWarningSub: 'Прогноз построен на априорных значениях — пройдите 12 заданий.',
    diagWarningBtn: 'Пройти диагностику',
    readinessTitle: 'Готовность к ЕНТ',
    confidenceLabel: 'данные:',
    intervalLabel: '95% интервал:',
    solvedTasks: 'Решено заданий',
    correctHint: 'верных',
    avgMastery: 'Средн. освоение',
    avgMasteryHint: 'по релевантным темам',
    topicsInPlan: 'Тем в плане',
    forecastDynamics: 'Динамика прогноза балла',
    masteryMap: 'Карта освоения',
    weakZonesTitle: 'Слабые зоны, выявленные системой',
    noWeakZones: 'Все темы выше 70%. Переходите к усложнению.',
    trainBtn: 'Тренировать',
    trajectoryTitle: 'Индивидуальная траектория подготовки',
    formulaHint: 'приоритет = вес_ЕНТ × дефицит¹·³',
    daysLeft: (d: number) => `до ЕНТ осталось ${d} дн.`,
    targetScore: (t: number) => `цель ${t} баллов`,
    accuracyLabel: (a: number) => `точность ${a}%`,
    dashboardTitle: 'Кабинет',
    masteryLabel: 'освоение',
    entWeightLabel: 'вес ЕНТ',
    minutesWeek: (m: number) => `${m} мин/нед`,
    confidenceHigh: 'высокая',
    confidenceMedium: 'средняя',
    confidenceLow: 'низкая',
  },
  kz: {
    loading: 'Жүктелуде…',
    noProfileTitle: 'Профиль жасалмаған',
    noProfileSub: 'Платформа жеке траектория құруы үшін профиль жасаңыз.',
    noProfileBtn: 'Профиль жасау',
    logoutBtn: 'Шығу',
    diagWarningTitle: 'Диагностика өтілмеді',
    diagWarningSub: 'Болжам априори мәндерге негізделген — 12 тапсырмадан өтіңіз.',
    diagWarningBtn: 'Диагностикадан өту',
    readinessTitle: 'ҰБТ-ға дайындық',
    confidenceLabel: 'деректер:',
    intervalLabel: '95% интервал:',
    solvedTasks: 'Шешілген тапсырмалар',
    correctHint: 'дұрыс',
    avgMastery: 'Орташа меңгеру',
    avgMasteryHint: 'қатысты тақырыптар бойынша',
    topicsInPlan: 'Жоспардағы тақырыптар',
    forecastDynamics: 'Балл болжамының динамикасы',
    masteryMap: 'Меңгеру картасы',
    weakZonesTitle: 'Жүйе анықтаған әлсіз аймақтар',
    noWeakZones: 'Барлық тақырыптар 70%-дан жоғары. Күрделендіруге көшіңіз.',
    trainBtn: 'Жаттығу',
    trajectoryTitle: 'Жеке дайындық траекториясы',
    formulaHint: 'басымдық = ҰБТ_салмағы × тапшылық¹·³',
    daysLeft: (d: number) => `ҰБТ-ға ${d} күн қалды`,
    targetScore: (t: number) => `мақсат ${t} балл`,
    accuracyLabel: (a: number) => `дәлдік ${a}%`,
    dashboardTitle: 'Кабинет',
    masteryLabel: 'меңгеру',
    entWeightLabel: 'ҰБТ салмағы',
    minutesWeek: (m: number) => `${m} мин/апта`,
    confidenceHigh: 'жоғары',
    confidenceMedium: 'орташа',
    confidenceLow: 'төмен',
  },
  en: {
    loading: 'Loading…',
    noProfileTitle: 'Profile not created',
    noProfileSub: 'Create a profile so the platform can build a personal trajectory.',
    noProfileBtn: 'Create Profile',
    logoutBtn: 'Log out',
    diagWarningTitle: 'Diagnostics not completed',
    diagWarningSub: 'Forecast is based on prior values — complete 12 tasks.',
    diagWarningBtn: 'Take Diagnostics',
    readinessTitle: 'ENT Readiness',
    confidenceLabel: 'data:',
    intervalLabel: '95% interval:',
    solvedTasks: 'Tasks Solved',
    correctHint: 'correct',
    avgMastery: 'Avg. Mastery',
    avgMasteryHint: 'on relevant topics',
    topicsInPlan: 'Topics in Plan',
    forecastDynamics: 'Score Forecast Dynamics',
    masteryMap: 'Mastery Map',
    weakZonesTitle: 'Weak Zones Identified by System',
    noWeakZones: 'All topics are above 70%. Proceed to advanced tasks.',
    trainBtn: 'Practice',
    trajectoryTitle: 'Individual Preparation Trajectory',
    formulaHint: 'priority = ENT_weight × deficit¹·³',
    daysLeft: (d: number) => `${d} days left until ENT`,
    targetScore: (t: number) => `target ${t} points`,
    accuracyLabel: (a: number) => `accuracy ${a}%`,
    dashboardTitle: 'Dashboard',
    masteryLabel: 'mastery',
    entWeightLabel: 'ENT weight',
    minutesWeek: (m: number) => `${m} min/week`,
    confidenceHigh: 'high',
    confidenceMedium: 'medium',
    confidenceLow: 'low',
  },
};

export default function Dashboard() {
  const r = useRouter();
  const st = useStore();
  const { lang } = useLanguage();
  const t = dict[lang];

  const view = useMemo(() => {
    if (!st.profile) return null;
    const f = forecast(st.profile.subjects, st.mastery, st.attemptsByTopic, st.customTopics, st.profile.target);
    const topics = relevantTopics(st.profile.subjects, st.customTopics);
    const plan = roadmap(st.profile.subjects, st.mastery, st.customTopics, st.profile.minutesPerDay);
    const days = Math.max(0, Math.ceil((new Date(st.profile.examDate).getTime() - Date.now()) / 86400000));
    const radar = topics.map((item) => ({ label: localizeTopic(item, lang).title, value: Math.round((st.mastery[item.id] ?? 0) * 100) }));
    const weak = plan.filter((p) => p.pL < 0.7).slice(0, 4);
    return { f, plan, days, radar, weak, topics };
  }, [st.profile, st.mastery, st.attemptsByTopic, st.customTopics, lang]);

  useEffect(() => {
    if (view) st.pushScore(view.f.predicted);
  }, [view?.f.predicted]); // eslint-disable-line react-hooks/exhaustive-deps

  if (!st.loaded) return <Shell><div className="wrap py-20 text-sm text-slate-500">{t.loading}</div></Shell>;
  if (!st.profile || !view) {
    return (
      <Shell>
        <div className="wrap max-w-xl py-20 text-center">
          <Title title={t.noProfileTitle} sub={t.noProfileSub} />
          <Btn className="mt-6" onClick={() => r.push('/onboarding')}>{t.noProfileBtn}</Btn>
        </div>
      </Shell>
    );
  }

  const { f, plan, days, radar, weak } = view;
  const accuracy = st.totalCount ? st.correctCount / st.totalCount : 0;
  const avgMastery = radar.length ? Math.round(radar.reduce((x, v) => x + v.value, 0) / radar.length) : 0;

  const handleLogout = () => {
    st.reset();
    window.location.reload();
  };

  return (
    <Shell>
      <div className="wrap space-y-4 py-10">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <Title
            eyebrow={`${st.profile.grade} ${lang === 'kz' ? 'сынып' : lang === 'en' ? 'grade' : 'класс'} · ${localizeRegion(st.profile.region, lang)}`}
            title={`${t.dashboardTitle} · ${st.profile.name}`}
            sub={`${st.profile.school} · ${t.daysLeft(days)} · ${t.targetScore(st.profile.target)}`}
          />
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2">
              <Badge color="#10B981">{st.xp} XP</Badge>
              <Badge color="#8B5CF6">{t.accuracyLabel(Math.round(accuracy * 100))}</Badge>
              <Btn size="sm" variant="ghost" onClick={handleLogout}>{t.logoutBtn}</Btn>
            </div>
          </div>
        </div>

        {!st.diagDone && (
          <Card className="border-[#F59E0B]/40 bg-[#F59E0B]/5">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div>
                <p className="text-sm font-medium">{t.diagWarningTitle}</p>
                <p className="mt-1 text-[13px] text-slate-400">{t.diagWarningSub}</p>
              </div>
              <Btn size="sm" onClick={() => r.push('/diagnostic')}>{t.diagWarningBtn}</Btn>
            </div>
          </Card>
        )}

        <div className="grid gap-4 lg:grid-cols-[350px_1fr]">
          <Card className="flex flex-col items-center">
            <div className="flex w-full items-center justify-between">
              <p className="text-[15px] font-semibold">{t.readinessTitle}</p>
              <Badge color={f.confidence === 'высокая' ? '#10B981' : f.confidence === 'средняя' ? '#F59E0B' : '#F43F5E'}>
                {t.confidenceLabel} {f.confidence === 'высокая' ? t.confidenceHigh : f.confidence === 'средняя' ? t.confidenceMedium : t.confidenceLow}
              </Badge>
            </div>
            <div className="my-5"><Gauge value={f.predicted / f.target} predicted={f.predicted} target={f.target} /></div>
            <p className="num text-xs text-slate-400">{t.intervalLabel} {f.low} – {f.high}</p>
            <div className="mt-5 w-full space-y-3 border-t border-[#1F2937] pt-5">
              {f.sections.map((s) => (
                <div key={s.id}>
                  <div className="flex justify-between text-[12px]">
                    <span className="text-slate-400">{localizeSectionLabel(s.label, lang)}</span>
                    <span className="num">{Math.round(s.points)} / {s.max}</span>
                  </div>
                  <div className="mt-1.5"><Bar value={s.points / s.max} /></div>
                </div>
              ))}
            </div>
          </Card>

          <div className="space-y-4">
            <div className="grid gap-4 sm:grid-cols-3">
              <Card><Stat label={t.solvedTasks} value={st.totalCount} hint={`${st.correctCount} ${t.correctHint}`} /></Card>
              <Card><Stat label={t.avgMastery} value={`${avgMastery}%`} hint={t.avgMasteryHint} /></Card>
              <Card><Stat label={t.topicsInPlan} value={plan.length} hint={t.minutesWeek(st.profile.minutesPerDay * 7)} /></Card>
            </div>
            <Card>
              <p className="text-[15px] font-semibold">{t.forecastDynamics}</p>
              <div className="mt-3"><Spark data={st.history} /></div>
            </Card>
          </div>
        </div>

        <div className="grid gap-4 lg:grid-cols-2">
          <Card>
            <p className="text-[15px] font-semibold">{t.masteryMap}</p>
            <Radar data={radar} />
          </Card>
          <Card>
            <p className="text-[15px] font-semibold">{t.weakZonesTitle}</p>
            <div className="mt-4 space-y-3">
              {weak.length === 0 && <p className="text-sm text-slate-400">{t.noWeakZones}</p>}
              {weak.map((w) => (
                <div key={w.topic.id} className="rounded-xl border border-[#1F2937] bg-[#0F1622] p-3.5">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="text-[13px] font-medium">{localizeTopic(w.topic, lang).title}</p>
                      <p className="num mt-0.5 text-[11px] text-slate-500">
                        {t.masteryLabel} {Math.round(w.pL * 100)}% · {t.entWeightLabel} {Math.round(w.topic.weight * 100)}% · {t.minutesWeek(w.minutes)}
                      </p>
                    </div>
                    <Btn size="sm" variant="soft" onClick={() => r.push('/practice')}>{t.trainBtn}</Btn>
                  </div>
                  <div className="mt-3"><Bar value={w.pL} /></div>
                </div>
              ))}
            </div>
          </Card>
        </div>

        <Card>
          <div className="flex flex-wrap items-center justify-between gap-3">
            <p className="text-[15px] font-semibold">{t.trajectoryTitle}</p>
            <span className="num text-[11px] text-slate-500">{t.formulaHint}</span>
          </div>
          <div className="mt-4 space-y-2">
            {plan.map((p, i) => (
              <div key={p.topic.id} className="flex items-center gap-3 rounded-xl border border-[#1F2937] bg-[#0F1622] p-3">
                <span className="num w-6 text-center text-xs text-slate-500">{i + 1}</span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[13px] font-medium">{localizeTopic(p.topic, lang).title}</p>
                  <div className="mt-2"><Bar value={p.pL} /></div>
                </div>
                <Badge color={p.reason === 'Пробел' ? '#F43F5E' : p.reason === 'Закрепление' ? '#F59E0B' : '#8B5CF6'}>{localizeReason(p.reason, lang)}</Badge>
                <span className="num w-16 text-right text-[11px] text-slate-500">{p.minutes} {lang === 'kz' ? 'мин/апта' : lang === 'en' ? 'min/week' : 'мин/нед'}</span>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </Shell>
  );
}
