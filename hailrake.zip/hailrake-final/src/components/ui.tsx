'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import type { ReactNode } from 'react';
import { useLanguage } from '@/context/LanguageContext';

export const cx = (...c: (string | false | undefined)[]) => c.filter(Boolean).join(' ');

export function Btn({ children, onClick, variant = 'primary', size = 'md', disabled, className, type = 'button' }: {
  children: ReactNode; onClick?: () => void; variant?: 'primary' | 'ghost' | 'soft';
  size?: 'sm' | 'md'; disabled?: boolean; className?: string; type?: 'button' | 'submit';
}) {
  const styles = {
    primary: 'bg-[#10B981] text-[#04120C] hover:brightness-110',
    ghost: 'border border-[#1F2937] text-slate-200 hover:border-[#10B981]/60',
    soft: 'bg-[#1F2937] text-slate-200 hover:bg-[#273244]',
  }[variant];
  return (
    <button type={type} onClick={onClick} disabled={disabled}
      className={cx('inline-flex items-center justify-center gap-2 rounded-xl font-medium transition-all active:scale-[.98] disabled:opacity-40',
        size === 'sm' ? 'h-9 px-3.5 text-[13px]' : 'h-11 px-5 text-sm', styles, className)}>
      {children}
    </button>
  );
}

export function Card({ children, className }: { children: ReactNode; className?: string }) {
  return <div className={cx('card', className)}>{children}</div>;
}

export function Badge({ children, color = '#94A3B8' }: { children: ReactNode; color?: string }) {
  return (
    <span className="inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px] font-medium"
      style={{ color, borderColor: `${color}55`, background: `${color}18` }}>
      {children}
    </span>
  );
}

export function Bar({ value, color }: { value: number; color?: string }) {
  const pct = Math.max(0, Math.min(100, value * 100));
  const c = color ?? (pct < 40 ? '#F43F5E' : pct < 70 ? '#F59E0B' : '#10B981');
  return (
    <div className="h-2 w-full overflow-hidden rounded-full bg-[#1F2937]">
      <div className="h-full rounded-full transition-all duration-700" style={{ width: `${pct}%`, background: c }} />
    </div>
  );
}

export function Stat({ label, value, hint }: { label: string; value: ReactNode; hint?: string }) {
  return (
    <div>
      <p className="text-[11px] uppercase tracking-wider text-slate-400">{label}</p>
      <p className="num mt-1 text-2xl font-semibold">{value}</p>
      {hint && <p className="mt-0.5 text-xs text-slate-500">{hint}</p>}
    </div>
  );
}

export function Field({ label, hint, children }: { label: string; hint?: string; children: ReactNode }) {
  return (
    <label className="block">
      <span className="text-[13px] font-medium text-slate-200">{label}</span>
      <div className="mt-2">{children}</div>
      {hint && <span className="mt-1.5 block text-xs text-slate-500">{hint}</span>}
    </label>
  );
}

const ctrl = 'w-full rounded-xl border border-[#1F2937] bg-[#0F1622] px-3.5 py-2.5 text-sm text-slate-100 outline-none focus:border-[#10B981] placeholder:text-slate-500';

export function Input(p: React.InputHTMLAttributes<HTMLInputElement>) {
  return <input {...p} className={cx(ctrl, p.className)} />;
}

export function Sel(p: React.SelectHTMLAttributes<HTMLSelectElement>) {
  return <select {...p} className={cx(ctrl, p.className)} />;
}

export function Title({ eyebrow, title, sub }: { eyebrow?: string; title: string; sub?: string }) {
  return (
    <div>
      {eyebrow && <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-[#10B981]">{eyebrow}</p>}
      <h1 className="mt-2 text-2xl font-semibold tracking-tight sm:text-3xl">{title}</h1>
      {sub && <p className="mt-2 max-w-2xl text-sm leading-relaxed text-slate-400">{sub}</p>}
    </div>
  );
}

export function Gauge({ value, predicted, target }: { value: number; predicted: number; target: number }) {
  const r = 66, circ = 2 * Math.PI * r;
  const fill = Math.max(0.02, Math.min(1, value)) * circ;
  return (
    <div className="relative grid h-[172px] w-[172px] place-items-center">
      <svg width="172" height="172" viewBox="0 0 172 172" className="-rotate-90">
        <circle cx="86" cy="86" r={r} fill="none" stroke="#1F2937" strokeWidth="12" />
        <circle cx="86" cy="86" r={r} fill="none" stroke="url(#g)" strokeWidth="12" strokeLinecap="round"
          strokeDasharray={`${fill} ${circ}`} className="transition-all duration-1000" />
        <defs>
          <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#10B981" /><stop offset="100%" stopColor="#8B5CF6" />
          </linearGradient>
        </defs>
      </svg>
      <div className="absolute text-center">
        <p className="num text-4xl font-bold leading-none">{predicted}</p>
        <p className="num mt-1 text-[11px] text-slate-400">/ {target}</p>
      </div>
    </div>
  );
}

export function Radar({ data }: { data: { label: string; value: number }[] }) {
  const { lang } = useLanguage();
  const empty = { ru: 'Недостаточно данных', kz: 'Деректер жеткіліксіз', en: 'Not enough data' }[lang];
  if (data.length < 3) return <p className="py-10 text-center text-sm text-slate-500">{empty}</p>;
  const n = data.length, cx0 = 150, cy0 = 140, R = 92;
  const pt = (i: number, rad: number) => {
    const ang = (Math.PI * 2 * i) / n - Math.PI / 2;
    return [cx0 + rad * Math.cos(ang), cy0 + rad * Math.sin(ang)];
  };
  const poly = data.map((d, i) => pt(i, (Math.max(5, d.value) / 100) * R).join(',')).join(' ');
  return (
    <svg viewBox="0 0 300 280" className="mx-auto w-full max-w-[340px]">
      {[0.25, 0.5, 0.75, 1].map((k) => (
        <polygon key={k} points={data.map((_, i) => pt(i, R * k).join(',')).join(' ')} fill="none" stroke="#1F2937" />
      ))}
      <polygon points={poly} fill="rgba(16,185,129,.25)" stroke="#10B981" strokeWidth="2" className="animate-pop" />
      {data.map((d, i) => {
        const [x, y] = pt(i, R + 20);
        return (
          <text key={d.label} x={x} y={y} fontSize="9" fill="#94A3B8" dominantBaseline="middle"
            textAnchor={x > cx0 + 5 ? 'start' : x < cx0 - 5 ? 'end' : 'middle'}>
            {d.label.length > 15 ? `${d.label.slice(0, 14)}…` : d.label}
          </text>
        );
      })}
    </svg>
  );
}

export function Spark({ data }: { data: number[] }) {
  const { lang } = useLanguage();
  const empty = { ru: 'Пройдите задания — появится график роста', kz: 'Тапсырмаларды орындаңыз — өсу графигі пайда болады', en: 'Complete some tasks to see the growth chart' }[lang];
  if (data.length < 2) return <p className="py-8 text-center text-sm text-slate-500">{empty}</p>;
  const W = 600, H = 140, p = 20;
  const min = Math.min(...data) - 3, max = Math.max(...data) + 3;
  const x = (i: number) => p + (i * (W - p * 2)) / (data.length - 1);
  const y = (v: number) => H - p - ((v - min) / Math.max(1, max - min)) * (H - p * 2);
  const line = data.map((v, i) => `${i ? 'L' : 'M'}${x(i)},${y(v)}`).join(' ');
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="w-full">
      <path d={`${line} L${x(data.length - 1)},${H - p} L${p},${H - p} Z`} fill="rgba(16,185,129,.15)" />
      <path d={line} fill="none" stroke="#10B981" strokeWidth="2.5" strokeLinecap="round" />
      {data.map((v, i) => <circle key={i} cx={x(i)} cy={y(v)} r="3" fill="#10B981" />)}
    </svg>
  );
}

const NAV = [
  { href: '/dashboard', labels: { ru: 'Кабинет', kz: 'Кабинет', en: 'Dashboard' } },
  { href: '/practice', labels: { ru: 'Практикум', kz: 'Практикум', en: 'Practice' } },
  { href: '/mentor', labels: { ru: 'ИИ-ментор', kz: 'AI-ментор', en: 'AI Mentor' } },
  { href: '/teacher', labels: { ru: 'Учителю', kz: 'Мұғалімге', en: 'Teacher' } },
];

export function Shell({ children }: { children: ReactNode }) {
  const path = usePathname();
  const { lang } = useLanguage();
  return (
    <div className="min-h-screen">
      <header className="sticky top-10 z-40 border-b border-[#1F2937] bg-[#0B0F17]/85 backdrop-blur">
        <div className="wrap flex h-16 items-center justify-between gap-4">
          <Link href="/" className="flex items-center gap-2.5">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-[#10B981]/15 text-[#10B981]">
              <span className="num text-sm font-bold">H</span>
            </span>
            <span className="hidden leading-tight sm:block">
              <span className="block text-[15px] font-semibold">Hailrake AI</span>
              <span className="num block text-[10px] uppercase tracking-widest text-slate-500">{({ ru: 'ЕНТ ментор', kz: 'ҰБТ ментор', en: 'ENT Mentor' } as const)[lang]}</span>
            </span>
          </Link>
          <div className="flex min-w-0 items-center gap-2">
            <nav className="flex items-center gap-1 overflow-x-auto">
              {NAV.map((n) => (
                <Link key={n.href} href={n.href}
                  className={cx('rounded-lg px-3 py-2 text-[13px] whitespace-nowrap transition-colors',
                    path.startsWith(n.href) ? 'bg-[#10B981]/12 text-[#10B981]' : 'text-slate-400 hover:text-slate-100')}>
                  {n.labels[lang]}
                </Link>
              ))}
            </nav>
          </div>
        </div>
      </header>
      <main className="pb-16">{children}</main>
    </div>
  );
}