'use client';

import { useLanguage } from '@/context/LanguageContext';
import type { Lang } from '@/lib/data';
import { cx } from '@/components/ui';

export function GlobalLanguageBar() {
  const { lang, setLang } = useLanguage();
  const labels: Record<Lang, string> = { ru: 'Русский', kz: 'Қазақша', en: 'English' };

  return (
    <div className="sticky top-0 z-[60] border-b border-[#1F2937] bg-[#080C13]">
      <div className="wrap flex h-10 items-center justify-end">
        <div className="flex items-center gap-1 rounded-lg border border-[#1F2937] bg-[#0F1622] p-1" aria-label={labels[lang]}>
          {(['ru', 'kz', 'en'] as const).map((l) => (
            <button
              key={l}
              type="button"
              onClick={() => setLang(l)}
              aria-pressed={lang === l}
              className={cx(
                'rounded-md px-2.5 py-1 text-[11px] font-semibold transition-all',
                lang === l ? 'bg-[#10B981] text-black' : 'text-slate-400 hover:text-white'
              )}
            >
              {labels[l]}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
