import { createClient } from '@supabase/supabase-js';

// anon key — публичный по дизайну Supabase, защита через RLS-политики в базе.
// Тот же Supabase-проект, что у Plastic School AI (переиспользован ради скорости,
// таблицы не пересекаются по именам: teachers/students vs classes/weight_records).
const FALLBACK_URL = 'https://elbvbjuidsqqgwtzebgq.supabase.co';
const FALLBACK_ANON_KEY = 'sb_publishable_w4598FcO_h51gigXb40aHQ_gNb7k_r-';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || FALLBACK_URL;
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || FALLBACK_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
