import { ITEMS, TOPICS, type Item, type SubjectId } from './data';

export const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));

export function pCorrect(theta: number, it: { a: number; b: number; c: number }) {
  return clamp(it.c + (1 - it.c) / (1 + Math.exp(-it.a * (theta - it.b))), 0.001, 0.999);
}

function slope(theta: number, it: { a: number; b: number; c: number }) {
  const s = 1 / (1 + Math.exp(-it.a * (theta - it.b)));
  return it.a * (1 - it.c) * s * (1 - s);
}

export function info(theta: number, it: { a: number; b: number; c: number }) {
  const p = pCorrect(theta, it);
  const d = slope(theta, it);
  return (d * d) / (p * (1 - p));
}


export function estimateTheta(res: { item: Item; correct: boolean }[]) {
  if (res.length === 0) return { theta: 0, se: 1.1 };
  let theta = 0;
  for (let k = 0; k < 50; k++) {
    let g = -theta / 1.21;
    let h = 1 / 1.21;
    for (const r of res) {
      const p = pCorrect(theta, r.item);
      const d = slope(theta, r.item);
      g += ((r.correct ? 1 : 0) - p) * (d / (p * (1 - p)));
      h += (d * d) / (p * (1 - p));
    }
    const step = clamp(g / h, -0.7, 0.7);
    theta = clamp(theta + step, -3, 3);
    if (Math.abs(step) < 1e-6) break;
  }
  let h = 1 / 1.21;
  for (const r of res) h += info(theta, r.item);
  return { theta, se: 1 / Math.sqrt(h) };
}


export function bkt(pL: number, correct: boolean) {
  const slip = 0.1, guess = 0.24, learn = 0.19;
  const prior = clamp(pL, 0.01, 0.99);
  const post = correct
    ? (prior * (1 - slip)) / (prior * (1 - slip) + (1 - prior) * guess)
    : (prior * slip) / (prior * slip + (1 - prior) * (1 - guess));
  return clamp(post + (1 - post) * learn, 0.02, 0.98);
}

export const seedMastery = (theta: number, it: { a: number; b: number; c: number }) =>
  clamp((pCorrect(theta, it) - it.c) / (1 - it.c), 0.05, 0.9);

export const itemsOf = (topicId: string, custom: Item[]) =>
  [...ITEMS, ...custom].filter((i) => i.topicId === topicId);

export function relevantTopics(subjects: SubjectId[], customTopics: typeof TOPICS) {
  return [...TOPICS, ...customTopics].filter((t) => t.subject === 'history' || subjects.includes(t.subject));
}


export function pickDiagnostic(pool: Item[], theta: number, used: Set<string>, counts: Record<string, number>) {
  const list = pool.filter((i) => !used.has(i.id));
  if (list.length === 0) return null;
  let best = list[0], score = -1;
  for (const it of list) {
    const s = info(theta, it) * (0.4 + 1 / (1 + (counts[it.topicId] || 0) * 1.8));
    if (s > score) { score = s; best = it; }
  }
  return best;
}

/** Практикум: держим вероятность успеха около 0.75 (зона роста). */
export function pickPractice(pool: Item[], theta: number, seen: string[]) {
  if (pool.length === 0) return null;
  const recent = new Set(seen.slice(-3));
  let best = pool[0], cost = 99;
  for (const it of pool) {
    const c = Math.abs(pCorrect(theta, it) - 0.75) + (recent.has(it.id) ? 1 : 0)
      + seen.filter((s) => s === it.id).length * 0.15;
    if (c < cost) { cost = c; best = it; }
  }
  return best;
}

export const acc = (pL: number) => clamp(0.25 + 0.75 * Math.pow(clamp(pL, 0, 1), 1.15), 0.25, 0.98);

export interface Section { id: string; label: string; max: number; subject: SubjectId | null }

export function blueprint(subjects: SubjectId[]): Section[] {
  return [
    { id: 'ml', label: 'Математическая грамотность', max: 10, subject: 'math' },
    { id: 'rd', label: 'Грамотность чтения', max: 10, subject: null },
    { id: 'hs', label: 'История Казахстана', max: 20, subject: 'history' },
    { id: 'p1', label: 'Профильный I', max: 50, subject: subjects[0] || 'math' },
    { id: 'p2', label: 'Профильный II', max: 50, subject: subjects[1] || 'physics' },
  ];
}


export function forecast(
  subjects: SubjectId[],
  mastery: Record<string, number>,
  attempts: Record<string, number>,
  customTopics: typeof TOPICS,
  target: number,
) {
  const all = [...TOPICS, ...customTopics];
  const sections = blueprint(subjects).map((s) => {
    const list = s.subject ? all.filter((t) => t.subject === s.subject) : [];
    if (list.length === 0) return { ...s, points: s.max * acc(0.4), accuracy: acc(0.4), covered: 0 };
    const wSum = list.reduce((x, t) => x + t.weight, 0) || 1;
    let a = 0, covered = 0;
    for (const t of list) {
      const share = t.weight / wSum;
      a += share * acc(mastery[t.id] ?? 0.28);
      if ((attempts[t.id] ?? 0) > 0) covered += share;
    }
    return { ...s, points: s.max * a, accuracy: a, covered };
  });

  let variance = 0;
  for (const s of sections) {
    const list = s.subject ? all.filter((t) => t.subject === s.subject) : [];
    if (list.length === 0) { variance += Math.pow(s.max * 0.22, 2); continue; }
    const wSum = list.reduce((x, t) => x + t.weight, 0) || 1;
    for (const t of list) {
      const pL = mastery[t.id] ?? 0.28;
      const n = (attempts[t.id] ?? 0) + 2;
      const share = (s.max * t.weight) / wSum;
      variance += share * share * ((pL * (1 - pL)) / n);
    }
  }

  const predicted = sections.reduce((x, s) => x + s.points, 0);
  const sd = Math.sqrt(variance);
  const cov = sections.reduce((x, s) => x + s.covered, 0) / sections.length;

  return {
    predicted: Math.round(predicted),
    low: Math.max(0, Math.round(predicted - 1.96 * sd)),
    high: Math.min(140, Math.round(predicted + 1.96 * sd)),
    target,
    sections,
    confidence: cov > 0.6 ? 'высокая' : cov > 0.3 ? 'средняя' : 'низкая',
  };
}


export function roadmap(subjects: SubjectId[], mastery: Record<string, number>, customTopics: typeof TOPICS, minutesPerDay: number) {
  const list = relevantTopics(subjects, customTopics);
  const scored = list.map((t) => {
    const pL = mastery[t.id] ?? 0.25;
    return {
      topic: t,
      pL,
      priority: clamp(t.weight * Math.pow(1 - pL, 1.3), 0, 1),
      reason: pL < 0.45 ? 'Пробел' : pL < 0.75 ? 'Закрепление' : 'Усложнение',
    };
  });
  const sum = scored.reduce((x, s) => x + s.priority, 0) || 1;
  const budget = minutesPerDay * 7;
  return scored
    .sort((a, b) => b.priority - a.priority)
    .map((s) => ({ ...s, minutes: Math.max(15, Math.round(((s.priority / sum) * budget) / 5) * 5) }));
}

function rnd(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const NAMES = ['Айгерим Сәдуақас', 'Диас Ермеков', 'Мадина Оспанова', 'Ерасыл Қайрат', 'Алина Ким', 'Нурсултан Абиш', 'Жанель Тлеу', 'Тимур Сагинтаев', 'Айша Нурланова', 'Данияр Бекен', 'Камила Ахмет', 'Арман Досжан', 'Сабина Жумаш', 'Алихан Мурат', 'Дана Серик', 'Рустем Калиев'];
const SCHOOLS = ['СШ №4, с. Мерке', 'ОШ №12, Аягоз', 'Гимназия №3, Тараз', 'СШ им. Абая, аул Кызылжар', 'СШ №7, Аральск'];

export interface ClassStudent {
  id: string; name: string; grade: number; region: string; school: string;
  subjects: SubjectId[]; mastery: Record<string, number>;
  attempts: number; accuracy: number; predicted: number; tier: string; you?: boolean;
}

export function buildClass(customTopics: typeof TOPICS): ClassStudent[] {
  const r = rnd(2026);
  const pairs: SubjectId[][] = [['math', 'physics'], ['math', 'history'], ['physics', 'history']];
  const all = [...TOPICS, ...customTopics];
  return NAMES.slice(0, 5).map((name, i) => {
    const base = 0.22 + r() * 0.6;
    const subjects = pairs[i % 3];
    const mastery: Record<string, number> = {};
    const attempts: Record<string, number> = {};
    for (const t of all) {
      mastery[t.id] = clamp(base + (r() - 0.5) * 0.3, 0.05, 0.96);
      attempts[t.id] = 6;
    }
    const f = forecast(subjects, mastery, attempts, customTopics, 110);
    return {
      id: `s${i}`, name, grade: 10 + (i % 2),
      region: REGION_POOL[i % REGION_POOL.length], school: SCHOOLS[i % SCHOOLS.length],
      subjects, mastery, attempts: 12 + Math.floor(r() * 80),
      accuracy: clamp(0.3 + base * 0.6, 0.2, 0.95),
      predicted: f.predicted, tier: tierOf(f.predicted),
    };
  });
}

const REGION_POOL = ['Туркестанская обл.', 'Жамбылская обл.', 'Абайская обл.', 'Кызылординская обл.', 'Актюбинская обл.', 'СКО', 'Алматинская обл.', 'Улытау'];

export function tierOf(p: number) {
  if (p < 55) return 'Критическая зона';
  if (p < 82) return 'Зона риска';
  if (p < 112) return 'Стабильные';
  return 'Высокий потенциал';
}

export const TIER_COLOR: Record<string, string> = {
  'Критическая зона': '#F43F5E',
  'Зона риска': '#F59E0B',
  'Стабильные': '#10B981',
  'Высокий потенциал': '#8B5CF6',
};