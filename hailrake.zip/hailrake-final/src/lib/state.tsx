'use client';
import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import type { Item, SubjectId, Topic, Lang } from './data';
import { bkt } from './engine';
import { syncStudentProgress, fetchClassContent } from './sync';

export interface Profile {
  id: string; name: string; grade: number; region: string; school: string;
  subjects: SubjectId[]; goal: string; target: number; examDate: string; minutesPerDay: number;
  teacherCode?: string;
}

export interface Msg { id: string; role: 'user' | 'ai'; text: string; hints?: string[]; source?: string; blocked?: boolean }

interface Store {
  loaded: boolean;
  lang: Lang;
  profile: Profile | null;
  mastery: Record<string, number>;
  attemptsByTopic: Record<string, number>;
  seenItems: string[];
  correctCount: number;
  totalCount: number;
  diagDone: boolean;
  scoreBefore: number;
  xp: number;
  history: number[];
  customTopics: Topic[];
  customItems: Item[];
  chat: Msg[];
  setLang: (lang: Lang) => void;
  saveProfile: (p: Profile) => void;
  applyDiagnostic: (mastery: Record<string, number>, counts: Record<string, number>, before: number) => void;
  answer: (topicId: string, itemId: string, correct: boolean) => { before: number; after: number };
  pushScore: (score: number) => void;
  addTopic: (t: Topic) => void;
  addItem: (i: Item) => void;
  addMsg: (m: Msg) => void;
  clearChat: () => void;
  reset: () => void;
}

const KEY = 'hailrake-v1';
const Ctx = createContext<Store | null>(null);

const EMPTY = {
  lang: 'ru' as Lang,
  profile: null as Profile | null,
  mastery: {} as Record<string, number>,
  attemptsByTopic: {} as Record<string, number>,
  seenItems: [] as string[],
  correctCount: 0,
  totalCount: 0,
  diagDone: false,
  scoreBefore: 0,
  xp: 0,
  history: [] as number[],
  customTopics: [] as Topic[],
  customItems: [] as Item[],
  chat: [] as Msg[],
};

export function StoreProvider({ children }: { children: ReactNode }) {
  const [loaded, setLoaded] = useState(false);
  const [s, setS] = useState(EMPTY);

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(KEY);
      if (raw) setS({ ...EMPTY, ...(JSON.parse(raw) as typeof EMPTY) });
    } catch {
      /* повреждённые данные игнорируем */
    }
    setLoaded(true);
  }, []);

  // Если у ученика указан код класса — подтягиваем темы/задания, которые добавил учитель.
  // Раньше это никогда не доходило до ученика: teacher.addTopic/addItem писали только в
  // localStorage браузера учителя. Сливаем по id, чтобы не плодить дубликаты при каждой загрузке.
  useEffect(() => {
    if (!loaded) return;
    const code = s.profile?.teacherCode?.trim();
    if (!code) return;
    fetchClassContent(code)
      .then(({ topics, items }) => {
        setS((v) => {
          const existingTopicIds = new Set(v.customTopics.map((x) => x.id));
          const existingItemIds = new Set(v.customItems.map((x) => x.id));
          const newTopics = topics.filter((x) => !existingTopicIds.has(x.id));
          const newItems = items.filter((x) => !existingItemIds.has(x.id));
          if (newTopics.length === 0 && newItems.length === 0) return v;
          return {
            ...v,
            customTopics: [...v.customTopics, ...newTopics],
            customItems: [...v.customItems, ...newItems],
          };
        });
      })
      .catch((err) => {
        console.log('⚠️ Не удалось загрузить контент класса:', err);
      });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loaded, s.profile?.teacherCode]);

  useEffect(() => {
    if (!loaded) return;
    try {
      window.localStorage.setItem(KEY, JSON.stringify(s));
    } catch {
      /* квота переполнена */
    }
  }, [s, loaded]);

  // Фоновая синхронизация с Supabase — только если есть профиль и пройдена диагностика
  // (иначе учителю нечего смотреть). teacherCode в профиле теперь хранит короткий код класса.
  // Дебаунс 800мс, чтобы не спамить запросами при каждом ответе.
  const syncTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  useEffect(() => {
    if (!loaded || !s.profile || !s.diagDone) return;
    if (syncTimer.current) clearTimeout(syncTimer.current);
    syncTimer.current = setTimeout(() => {
      syncStudentProgress(
        s.profile as Profile,
        s.mastery,
        s.attemptsByTopic,
        s.correctCount,
        s.totalCount,
        s.xp,
        s.profile?.teacherCode?.trim() ?? ''
      );
    }, 800);
    return () => {
      if (syncTimer.current) clearTimeout(syncTimer.current);
    };
  }, [loaded, s.profile, s.diagDone, s.mastery, s.attemptsByTopic, s.correctCount, s.totalCount, s.xp]);

  useEffect(() => {
    const syncFromOtherTab = (event: StorageEvent) => {
      if (event.key !== KEY || !event.newValue) return;
      try {
        setS({ ...EMPTY, ...(JSON.parse(event.newValue) as typeof EMPTY) });
      } catch {
        /* повреждённые данные игнорируем */
      }
    };
    window.addEventListener('storage', syncFromOtherTab);
    return () => window.removeEventListener('storage', syncFromOtherTab);
  }, []);

  const setLang = useCallback((lang: Lang) => setS((v) => ({ ...v, lang })), []);

  const saveProfile = useCallback((p: Profile) => setS((v) => ({ ...v, profile: p })), []);

  const applyDiagnostic = useCallback((mastery: Record<string, number>, counts: Record<string, number>, before: number) => {
    setS((v) => ({
      ...v,
      mastery: { ...v.mastery, ...mastery },
      attemptsByTopic: { ...v.attemptsByTopic, ...counts },
      diagDone: true,
      scoreBefore: before,
      xp: v.xp + 60,
    }));
  }, []);

  const answer = useCallback((topicId: string, itemId: string, correct: boolean) => {
    const before = s.mastery[topicId] ?? 0.25;
    const after = bkt(before, correct);
    setS((v) => ({
      ...v,
      mastery: { ...v.mastery, [topicId]: after },
      attemptsByTopic: { ...v.attemptsByTopic, [topicId]: (v.attemptsByTopic[topicId] ?? 0) + 1 },
      seenItems: [...v.seenItems, itemId].slice(-60),
      correctCount: v.correctCount + (correct ? 1 : 0),
      totalCount: v.totalCount + 1,
      xp: v.xp + (correct ? 12 : 5),
    }));
    return { before, after };
  }, [s.mastery]);

  const pushScore = useCallback((score: number) => {
    setS((v) => (v.history[v.history.length - 1] === score ? v : { ...v, history: [...v.history, score].slice(-12) }));
  }, []);

  const value = useMemo<Store>(() => ({
    loaded, ...s, setLang, saveProfile, applyDiagnostic, answer, pushScore,
    addTopic: (t) => setS((v) => ({ ...v, customTopics: [...v.customTopics, t] })),
    addItem: (i) => setS((v) => ({ ...v, customItems: [...v.customItems, i] })),
    addMsg: (m) => setS((v) => ({ ...v, chat: [...v.chat, m] })),
    clearChat: () => setS((v) => ({ ...v, chat: [] })),
    reset: () => setS(EMPTY),
  }), [loaded, s, setLang, saveProfile, applyDiagnostic, answer, pushScore]);

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useStore() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error('useStore must be used inside StoreProvider');
  return ctx;
}