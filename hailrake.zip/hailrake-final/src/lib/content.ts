import type { Item, SubjectId, Topic, Lang } from '@/lib/data';

type TopicText = Pick<Topic, 'title' | 'theory'>;
type ItemText = Pick<Item, 'skill' | 'stem' | 'options' | 'explain'> & { trap?: string };

const TOPIC_KZ: Record<string, TopicText> = {
  quad: { title: 'Квадрат теңдеулер мен теңсіздіктер', theory: {
    core: 'ax² + bx + c = 0 (a ≠ 0) теңдеуі. Түбірлер саны дискриминанттың таңбасымен анықталады.',
    formulas: ['D = b² − 4ac', 'x = (−b ± √D)/(2a)', 'x₁ + x₂ = −b/a', 'x₁·x₂ = c/a'],
    steps: ['Стандартты түрге келтіру', 'D мәнін есептеу', 'Түбірлерді табу немесе Виет теоремасын қолдану', 'Теңсіздік үшін парабола тармақтарының таңбасын анықтау'],
    mistake: 'Теңсіздікте ішкі аралықтың орнына сыртқы аралықты алады.',
  }},
  prog: { title: 'Прогрессиялар', theory: {
    core: 'Арифметикалық прогрессияда тұрақты айырма d, геометриялық прогрессияда тұрақты қатынас q болады.',
    formulas: ['aₙ = a₁ + (n − 1)d', 'Sₙ = n(a₁ + aₙ)/2', 'bₙ = b₁qⁿ⁻¹', 'S = b₁/(1 − q), |q| < 1'],
    steps: ['Прогрессия түрін анықтау', 'a₁, d немесе q және n мәндерін жазу', 'Мүше немесе қосынды формуласын таңдау', 'Жинақталу шартын тексеру'],
    mistake: 'n-ші мүше формуласында (n − 1) орнына n қояды.',
  }},
  log: { title: 'Логарифмдер мен дәрежелер', theory: {
    core: 'log_a b = c ⇔ aᶜ = b, мұнда a > 0, a ≠ 1, b > 0. Анықталу облысы әрқашан тексеріледі.',
    formulas: ['log_a(xy) = log_a x + log_a y', 'log_a xᵏ = k·log_a x', 'a^(log_a x) = x'],
    steps: ['Анықталу облысын жазу', 'Бір негізге келтіру', 'Алгебралық теңдеуге көшу', 'Анықталу облысына кірмейтін түбірлерді алып тастау'],
    mistake: 'Логарифм аргументтерін көбейтудің орнына қосады.',
  }},
  kin: { title: 'Кинематика', theory: {
    core: 'Қозғалыстың себептерін талдамай, жол, жылдамдық, үдеу және уақыт арасындағы байланысты сипаттау.',
    formulas: ['v = v₀ + at', 's = v₀t + at²/2', 'v² − v₀² = 2as', 'h = v₀²/(2g)'],
    steps: ['Ось пен бағытты таңдау', 'Шамаларды SI жүйесіне айналдыру', 'Бір белгісізі бар теңдеуді таңдау', 'Өлшем бірліктерін тексеру'],
    mistake: 't² және v² бар формулаларда 2-ге бөлуді ұмытады.',
  }},
  dyn: { title: 'Динамика: Ньютон заңдары', theory: {
    core: 'Үдеу қорытқы күшке тура, массаға кері пропорционал.',
    formulas: ['F = ma', 'F_тр = μN', 'F_ц = mv²/R', 'P = mg'],
    steps: ['Барлық күштерді көрсету', 'Осьтерді таңдап, проекцияларға жіктеу', 'Екінші заңды проекциялар бойынша жазу', 'Белгісіз шамаға қатысты шешу'],
    mistake: 'Үйкеліс күшін салмаққа теңестіріп, μ көбейткішін жоғалтады.',
  }},
  dc: { title: 'Тұрақты ток', theory: {
    core: 'Ток, кернеу және кедергі арасындағы байланыс; тізбектер мен қуатты есептеу.',
    formulas: ['I = U/R', 'R_тізб = R₁ + R₂', '1/R_пар = 1/R₁ + 1/R₂', 'P = UI = I²R'],
    steps: ['Қосылу түрін анықтау', 'Тізбекті эквивалентті R-ге дейін ықшамдау', 'Жалпы токты табу', 'Қажетті бөлікке қайта оралу'],
    mistake: 'Параллель қосылғанда кедергілерді қосады.',
  }},
  sak: { title: 'Сақ дәуірі', theory: {
    core: 'Б.з.д. I мыңжылдық: сақ тайпаларының бірлестіктері, көшпелі мемлекеттілік және «аң стилі».',
    formulas: ['Есік — Алматы облысы', 'Берел — Шығыс Қазақстан', 'Томирис — Кир II-ні жеңген'],
    steps: ['Ескерткішті аймақпен байланыстыру', 'Билеушіні оқиғамен сәйкестендіру', 'Мәдениетті саясаттан ажырату', 'Хронологияны тексеру'],
    mistake: 'Есік пен Берел қорғандарының орналасуын шатастырады.',
  }},
  khan: { title: 'XV–XVIII ғғ. Қазақ хандығы', theory: {
    core: 'Хандықтың 1465 жылы құрылуы, құқықтық жарғылар және Жоңғариямен күрес.',
    formulas: ['1465 — құрылуы', '1643 — Орбұлақ', '«Жеті жарғы» — Тәуке хан', '1731 — Кіші жүз'],
    steps: ['Хандардың хронологиясын құру', 'Ханды оқиғамен байланыстыру', 'Реформаларды сыртқы саясаттан ажырату', 'Негізгі даталарды тексеру'],
    mistake: '«Жеті жарғыны» Тәуке ханның орнына Есім ханға телиді.',
  }},
  ind: { title: 'XX ғасыр және Тәуелсіздік', theory: {
    core: '1986 жылғы Желтоқсан оқиғасы, 1990 жылғы мемлекеттік егемендік туралы декларация, 1991 жылғы 16 желтоқсандағы тәуелсіздік.',
    formulas: ['1986 — Желтоқсан оқиғасы', '25.10.1990 — егемендік', '16.12.1991 — тәуелсіздік', '02.03.1992 — БҰҰ'],
    steps: ['Негізгі даталарды бекіту', 'Құжатты оның мәртебесімен сәйкестендіру', 'Оқиғалар арасындағы байланысты қадағалау', 'Реттілігін тексеру'],
    mistake: '1990 жылғы декларация мен 1991 жылғы тәуелсіздік туралы заңды шатастырады.',
  }},
};

const TOPIC_EN: Record<string, TopicText> = {
  quad: { title: 'Quadratic Equations and Inequalities', theory: {
    core: 'The equation ax² + bx + c = 0 (a ≠ 0). The number of roots is determined by the sign of the discriminant.',
    formulas: ['D = b² − 4ac', 'x = (−b ± √D)/(2a)', 'x₁ + x₂ = −b/a', 'x₁·x₂ = c/a'],
    steps: ['Put the equation in standard form', 'Calculate D', 'Find the roots or use Vieta’s theorem', 'For an inequality, determine the sign from the parabola branches'],
    mistake: 'For an inequality, the outer interval is chosen instead of the inner interval.',
  }},
  prog: { title: 'Progressions', theory: {
    core: 'An arithmetic progression has a constant difference d; a geometric progression has a constant ratio q.',
    formulas: ['aₙ = a₁ + (n − 1)d', 'Sₙ = n(a₁ + aₙ)/2', 'bₙ = b₁qⁿ⁻¹', 'S = b₁/(1 − q) when |q| < 1'],
    steps: ['Identify the progression type', 'Write a₁, d or q, and n', 'Choose the formula for a term or sum', 'Check the convergence condition'],
    mistake: 'n is substituted instead of (n − 1) in the nth-term formula.',
  }},
  log: { title: 'Logarithms and Powers', theory: {
    core: 'log_a b = c ⇔ aᶜ = b for a > 0, a ≠ 1, b > 0. Domain restrictions must always be checked.',
    formulas: ['log_a(xy) = log_a x + log_a y', 'log_a xᵏ = k·log_a x', 'a^(log_a x) = x'],
    steps: ['Write the domain restrictions', 'Reduce to one base', 'Convert to an algebraic equation', 'Discard roots outside the domain'],
    mistake: 'Logarithm arguments are added instead of multiplied.',
  }},
  kin: { title: 'Kinematics', theory: {
    core: 'Describes motion without analyzing its causes: the relationship between distance, velocity, acceleration, and time.',
    formulas: ['v = v₀ + at', 's = v₀t + at²/2', 'v² − v₀² = 2as', 'h = v₀²/(2g)'],
    steps: ['Choose an axis and direction', 'Convert quantities to SI units', 'Choose an equation with one unknown', 'Check the units'],
    mistake: 'The division by 2 is forgotten in formulas containing t² and v².',
  }},
  dyn: { title: 'Dynamics: Newton’s Laws', theory: {
    core: 'Acceleration is proportional to the net force and inversely proportional to mass.',
    formulas: ['F = ma', 'F_f = μN', 'F_c = mv²/R', 'P = mg'],
    steps: ['Draw all forces', 'Choose axes and resolve into components', 'Write Newton’s second law in components', 'Solve for the unknown'],
    mistake: 'Friction is equated to weight, losing the factor μ.',
  }},
  dc: { title: 'Direct Current', theory: {
    core: 'The relationship between current, voltage, and resistance; circuit and power calculations.',
    formulas: ['I = U/R', 'R_series = R₁ + R₂', '1/R_parallel = 1/R₁ + 1/R₂', 'P = UI = I²R'],
    steps: ['Identify the connection type', 'Reduce the circuit to an equivalent R', 'Find the total current', 'Return to the required section'],
    mistake: 'Resistances are added for a parallel connection.',
  }},
  sak: { title: 'Saka Era', theory: {
    core: '1st millennium BCE: Saka tribal unions, nomadic statehood, and the “animal style”.',
    formulas: ['Issyk — Almaty Region', 'Berel — East Kazakhstan', 'Tomyris — defeated Cyrus II'],
    steps: ['Match the monument to its region', 'Match the ruler to the event', 'Separate culture from politics', 'Check the chronology'],
    mistake: 'The locations of the Issyk and Berel burial mounds are confused.',
  }},
  khan: { title: 'Kazakh Khanate, 15th–18th centuries', theory: {
    core: 'The khanate was formed in 1465; this period includes legal codes and conflicts with Dzungaria.',
    formulas: ['1465 — formation', '1643 — Orbulak', '“Zheti Zhargy” — Tauke Khan', '1731 — Junior Zhuz'],
    steps: ['Build a chronology of the khans', 'Connect each khan with an event', 'Separate reforms from foreign policy', 'Check key dates'],
    mistake: '“Zheti Zhargy” is attributed to Esim Khan instead of Tauke Khan.',
  }},
  ind: { title: '20th Century and Independence', theory: {
    core: 'The December 1986 events, the 1990 Declaration of State Sovereignty, and independence on December 16, 1991.',
    formulas: ['1986 — December events', '25.10.1990 — sovereignty', '16.12.1991 — independence', '02.03.1992 — UN'],
    steps: ['Fix the key dates', 'Match each document with its status', 'Trace the connection between events', 'Check the order'],
    mistake: 'The 1990 sovereignty declaration and the 1991 independence law are confused.',
  }},
};

const ITEM_KZ: Record<string, ItemText> = {
  i1:{skill:'Виет теоремасы',stem:'x² − 7x + 12 = 0 теңдеуінің түбірлерінің қосындысын табыңыз.',options:['7','12','−7','5'],explain:'Виет теоремасы бойынша түбірлер қосындысы −p = 7 (түбірлері 3 және 4).',trap:'12 — түбірлердің қосындысы емес, көбейтіндісі.'},
  i2:{skill:'Дискриминант',stem:'2x² − 4x + 5 = 0 теңдеуінің неше нақты түбірі бар?',options:['2','1','0','Шексіз көп'],explain:'D = 16 − 40 = −24 < 0, нақты түбірлері жоқ.',trap:'Дискриминант таңбасын тексермей «2» деп жауап береді.'},
  i3:{skill:'Квадрат теңсіздіктер',stem:'x² − 5x + 6 < 0 теңсіздігін шешіңіз.',options:['(2; 3)','(−∞; 2) ∪ (3; +∞)','[2; 3]','(−3; −2)'],explain:'Түбірлері 2 және 3, тармақтары жоғары қарайды, сондықтан өрнек түбірлердің арасында қатаң түрде теріс.',trap:'Екінші нұсқа — кері теңсіздіктің шешімі.'},
  i4:{skill:'n-ші мүше',stem:'Арифметикалық прогрессияда a₁ = 3, d = 4. a₁₀ мәнін табыңыз.',options:['39','40','43','36'],explain:'aₙ = a₁ + (n − 1)d = 3 + 36 = 39.',trap:'43 қате түрде a₁ + n·d қолданғанда шығады.'},
  i5:{skill:'Прогрессия қосындысы',stem:'a₁ = 2, a₂₀ = 40 болса, алғашқы 20 мүшенің қосындысын табыңыз.',options:['420','400','840','210'],explain:'Sₙ = n(a₁ + aₙ)/2 = 20·42/2 = 420.',trap:'840 — 2-ге бөлуді ұмытып кеткенде шығады.'},
  i6:{skill:'Шексіз қосынды',stem:'Шексіз геометриялық прогрессияның қосындысы: b₁ = 8, q = 1/2.',options:['16','12','8','Жоқ'],explain:'|q| < 1 кезінде S = b₁/(1 − q) = 8/0,5 = 16.',trap:'12 — тек алғашқы екі мүшенің қосындысы.'},
  i7:{skill:'Логарифм анықтамасы',stem:'log₂ 32 мәнін есептеңіз.',options:['5','4','6','16'],explain:'32 = 2⁵, сондықтан log₂ 32 = 5.'},
  i8:{skill:'Логарифмдік теңдеу',stem:'log₃(x − 1) = 2 теңдеуін шешіңіз.',options:['x = 10','x = 7','x = 9','x = 8'],explain:'x − 1 = 9 ⇒ x = 10; x > 1 анықталу облысы орындалады.',trap:'x = 9 — −1-ді ескеруді ұмытады.'},
  i9:{skill:'Логарифм қасиеттері',stem:'log₆ 2 + log₆ 18 мәнін есептеңіз.',options:['2','1','36','log₆ 20'],explain:'log₆(2·18) = log₆ 36 = 2.',trap:'log₆ 20 — аргументтерді көбейтудің орнына қосты.'},
  i10:{skill:'Өлшем бірліктері',stem:'72 км/сағ мәнін м/с-қа айналдырыңыз.',options:['20 м/с','7,2 м/с','200 м/с','72 м/с'],explain:'72 : 3,6 = 20 м/с.'},
  i11:{skill:'Еркін түсу',stem:'Дене 3 с еркін құлайды. Жолды табыңыз (g = 10 м/с²).',options:['45 м','90 м','30 м','15 м'],explain:'s = gt²/2 = 10·9/2 = 45 м.',trap:'90 м — 2-ге бөлуді ұмытады.'},
  i12:{skill:'Бірқалыпты үдемелі қозғалыс',stem:'v₀ = 5 м/с, a = 2 м/с². 4 с ішінде қандай жол жүрілді?',options:['36 м','28 м','52 м','20 м'],explain:'s = v₀t + at²/2 = 20 + 16 = 36 м.',trap:'20 м — тек бірқалыпты қозғалыс бөлігін есептеген.'},
  i13:{skill:'Ньютонның екінші заңы',stem:'Массасы 2 кг денеге 10 Н күш әсер етеді. Үдеуді табыңыз.',options:['5 м/с²','20 м/с²','0,2 м/с²','12 м/с²'],explain:'a = F/m = 10/2 = 5 м/с².'},
  i14:{skill:'Үйкеліс күші',stem:'Массасы 4 кг дене, μ = 0,25, g = 10 м/с². Үйкеліс күшін табыңыз.',options:['10 Н','40 Н','1 Н','2,5 Н'],explain:'F = μmg = 0,25·4·10 = 10 Н.',trap:'40 Н — бұл дененің салмағы, үйкеліс күші емес.'},
  i15:{skill:'Центрге тартқыш күш',stem:'Жылдамдық пен радиус екі есе артса, центрге тартқыш күш қалай өзгереді?',options:['2 есе артады','Өзгермейді','4 есе артады','2 есе кемиді'],explain:'F = mv²/R: алым ×4, бөлім ×2, сондықтан күш 2 есе артады.',trap:'«Өзгермейді» — v-ге тәуелділікті сызықтық деп есептейді.'},
  i16:{skill:'Ом заңы',stem:'U = 12 В, R = 4 Ом. Ток күшін табыңыз.',options:['3 А','48 А','0,33 А','8 А'],explain:'I = U/R = 12/4 = 3 А.'},
  i17:{skill:'Параллель қосылу',stem:'6 Ом және 3 Ом резисторлар параллель қосылған. Жалпы кедергі қандай?',options:['2 Ом','9 Ом','4,5 Ом','18 Ом'],explain:'1/R = 1/6 + 1/3 = 1/2 ⇒ R = 2 Ом.',trap:'9 Ом — тізбектей қосылу формуласы.'},
  i18:{skill:'Қуат',stem:'5 Ом резистор арқылы 2 А ток өтеді. Қуатты табыңыз.',options:['20 Вт','10 Вт','40 Вт','2,5 Вт'],explain:'P = I²R = 4·5 = 20 Вт.',trap:'10 Вт — P = IR формуласын қате қолданған.'},
  i19:{skill:'Хронология',stem:'Сақ тайпалары Қазақстан аумағында қай кезеңде өмір сүрді?',options:['Б.з.д. I мыңжылдық','Б.з. I мыңжылдық','Б.з.д. III–II мыңжылдық','Б.з. V–VI ғғ.'],explain:'Сақ дәуірі — ерте темір дәуірі, б.з.д. I мыңжылдық.'},
  i20:{skill:'Сақ билеушілері',stem:'Геродоттың дерегіне сәйкес, парсы патшасы Кир II-нің әскерін кім жеңді?',options:['Томирис','Зарина','Спаргапис','Скилур'],explain:'Массагеттердің патшайымы Томирис; сол шайқаста Кир II қаза тапты.',trap:'Спаргапис — Томиристің ұлы.'},
  i21:{skill:'Ескерткіштер',stem:'«Патша» қорғандарының Берел кешені қай жерде орналасқан?',options:['Шығыс Қазақстанда','Батыс Қазақстанда','Орталық Қазақстанда','Оңтүстік Қазақстанда'],explain:'Берел — Бұқтырма өзені аңғары, Шығыс Қазақстан.',trap:'Оны Алматы облысындағы Есікпен шатастырады.'},
  i22:{skill:'Негізгі даталар',stem:'Қазақ хандығының құрылу жылы ретінде қай жыл қабылданған?',options:['1465 ж.','1511 ж.','1428 ж.','1731 ж.'],explain:'Дәстүрлі дата — 1465 жыл, Керей мен Жәнібек Батыс Жетісуда.',trap:'1731 ж. — Кіші жүздің Ресей бодандығын қабылдауы.'},
  i23:{skill:'Құқықтық ескерткіштер',stem:'«Жеті жарғы» заңдар жинағы кімнің атымен байланысты?',options:['Тәуке хан','Есім хан','Хақназар хан','Абылай хан'],explain:'«Жеті жарғы» XVII–XVIII ғасырлар тоғысында Тәуке хан тұсында қалыптасты.',trap:'«Есім ханның ескі жолы» — Есім ханға қатысты ескерткіш.'},
  i24:{skill:'Әскери тарих',stem:'1643 жылғы Орбұлақ шайқасында әскерді кім басқарды?',options:['Жәңгір хан','Есім хан','Абылай хан','Тәуекел хан'],explain:'Жәңгір ханның жасағы жоңғарлардың басым күшін тоқтатты.'},
  i25:{skill:'Тәуелсіздікке жол',stem:'Қазақ КСР-нің мемлекеттік егемендігі туралы декларация қашан қабылданды?',options:['1990 жылғы 25 қазан','1991 жылғы 16 желтоқсан','1991 жылғы 1 желтоқсан','1995 жылғы 30 тамыз'],explain:'Декларацияны Жоғарғы Кеңес 1990 жылғы 25 қазанда қабылдады.',trap:'1995 жылғы 30 тамыз — ҚР Конституциясы қабылданған күн.'},
  i26:{skill:'Мемлекеттілік',stem:'«Қазақстан Республикасының мемлекеттік тәуелсіздігі туралы» конституциялық заң қашан қабылданды?',options:['1991 жылғы 16 желтоқсан','1990 жылғы 25 қазан','1991 жылғы 10 желтоқсан','1992 жылғы 2 наурыз'],explain:'Мемлекеттік тәуелсіздік туралы заң 1991 жылғы 16 желтоқсанда қабылданды.'},
  i27:{skill:'Қоғамдық қозғалыстар',stem:'Алма-Атадағы Желтоқсан оқиғалары қай жылы болды?',options:['1986 ж.','1979 ж.','1991 ж.','1989 ж.'],explain:'Жастардың 1986 жылғы 17–18 желтоқсандағы наразылықтары.',trap:'1979 ж. — Целиноградтағы оқиғалар.'},
};

const ITEM_EN: Record<string, ItemText> = {
  i1:{skill:"Vieta’s Theorem",stem:'Find the sum of the roots of x² − 7x + 12 = 0.',options:['7','12','−7','5'],explain:'By Vieta’s theorem, the sum of the roots is −p = 7 (the roots are 3 and 4).',trap:'12 is the product of the roots, not their sum.'},
  i2:{skill:'Discriminant',stem:'How many real roots does 2x² − 4x + 5 = 0 have?',options:['2','1','0','Infinitely many'],explain:'D = 16 − 40 = −24 < 0, so there are no real roots.',trap:'“2” is chosen without checking the sign of the discriminant.'},
  i3:{skill:'Quadratic Inequalities',stem:'Solve the inequality x² − 5x + 6 < 0.',options:['(2; 3)','(−∞; 2) ∪ (3; +∞)','[2; 3]','(−3; −2)'],explain:'The roots are 2 and 3 and the parabola opens upward, so the expression is strictly negative between the roots.',trap:'The second option solves the reverse inequality.'},
  i4:{skill:'Nth Term',stem:'In an arithmetic progression a₁ = 3, d = 4. Find a₁₀.',options:['39','40','43','36'],explain:'aₙ = a₁ + (n − 1)d = 3 + 36 = 39.',trap:'43 results from incorrectly using a₁ + n·d.'},
  i5:{skill:'Progression Sum',stem:'Find the sum of the first 20 terms if a₁ = 2 and a₂₀ = 40.',options:['420','400','840','210'],explain:'Sₙ = n(a₁ + aₙ)/2 = 20·42/2 = 420.',trap:'840 results from forgetting to divide by 2.'},
  i6:{skill:'Infinite Sum',stem:'Find the sum of an infinite geometric progression with b₁ = 8 and q = 1/2.',options:['16','12','8','Does not exist'],explain:'For |q| < 1: S = b₁/(1 − q) = 8/0.5 = 16.',trap:'12 is the sum of only the first two terms.'},
  i7:{skill:'Logarithm Definition',stem:'Calculate log₂ 32.',options:['5','4','6','16'],explain:'32 = 2⁵, so log₂ 32 = 5.'},
  i8:{skill:'Logarithmic Equation',stem:'Solve log₃(x − 1) = 2.',options:['x = 10','x = 7','x = 9','x = 8'],explain:'x − 1 = 9 ⇒ x = 10; the domain x > 1 is satisfied.',trap:'x = 9 forgets to add 1 after solving for x − 1.'},
  i9:{skill:'Logarithm Properties',stem:'Calculate log₆ 2 + log₆ 18.',options:['2','1','36','log₆ 20'],explain:'log₆(2·18) = log₆ 36 = 2.',trap:'log₆ 20 comes from adding the arguments instead of multiplying them.'},
  i10:{skill:'Units',stem:'Convert 72 km/h to m/s.',options:['20 m/s','7.2 m/s','200 m/s','72 m/s'],explain:'72 ÷ 3.6 = 20 m/s.'},
  i11:{skill:'Free Fall',stem:'A body falls freely for 3 s. Find the distance (g = 10 m/s²).',options:['45 m','90 m','30 m','15 m'],explain:'s = gt²/2 = 10·9/2 = 45 m.',trap:'90 m results from forgetting to divide by 2.'},
  i12:{skill:'Uniformly Accelerated Motion',stem:'v₀ = 5 m/s, a = 2 m/s². What distance is covered in 4 s?',options:['36 m','28 m','52 m','20 m'],explain:'s = v₀t + at²/2 = 20 + 16 = 36 m.',trap:'20 m accounts only for the uniform-motion part.'},
  i13:{skill:'Newton’s Second Law',stem:'A 2 kg body is acted on by a 10 N force. Find its acceleration.',options:['5 m/s²','20 m/s²','0.2 m/s²','12 m/s²'],explain:'a = F/m = 10/2 = 5 m/s².'},
  i14:{skill:'Friction Force',stem:'A 4 kg body has μ = 0.25 and g = 10 m/s². Find the friction force.',options:['10 N','40 N','1 N','2.5 N'],explain:'F = μmg = 0.25·4·10 = 10 N.',trap:'40 N is the weight of the body, not the friction force.'},
  i15:{skill:'Centripetal Force',stem:'How does the centripetal force change if both speed and radius are doubled?',options:['Increases 2 times','Does not change','Increases 4 times','Decreases 2 times'],explain:'F = mv²/R: the numerator increases ×4 and the denominator ×2, so the force increases ×2.',trap:'“Does not change” treats the dependence on v as linear.'},
  i16:{skill:'Ohm’s Law',stem:'U = 12 V, R = 4 Ω. Find the current.',options:['3 A','48 A','0.33 A','8 A'],explain:'I = U/R = 12/4 = 3 A.'},
  i17:{skill:'Parallel Connection',stem:'6 Ω and 3 Ω resistors are connected in parallel. What is the total resistance?',options:['2 Ω','9 Ω','4.5 Ω','18 Ω'],explain:'1/R = 1/6 + 1/3 = 1/2 ⇒ R = 2 Ω.',trap:'9 Ω is the formula for a series connection.'},
  i18:{skill:'Power',stem:'A current of 2 A flows through a 5 Ω resistor. Find the power.',options:['20 W','10 W','40 W','2.5 W'],explain:'P = I²R = 4·5 = 20 W.',trap:'10 W comes from incorrectly using P = IR without the square.'},
  i19:{skill:'Chronology',stem:'During which period did the Saka tribes live in the territory of Kazakhstan?',options:['1st millennium BCE','1st millennium CE','3rd–2nd millennium BCE','5th–6th centuries CE'],explain:'The Saka era belongs to the Early Iron Age, 1st millennium BCE.'},
  i20:{skill:'Saka Rulers',stem:'According to Herodotus, who defeated the army of the Persian king Cyrus II?',options:['Tomyris','Zarina','Spargapises','Scylurus'],explain:'Tomyris, queen of the Massagetae; Cyrus II died in that battle.',trap:'Spargapises was Tomyris’s son.'},
  i21:{skill:'Monuments',stem:'Where is the Berel complex of “royal” burial mounds located?',options:['East Kazakhstan','West Kazakhstan','Central Kazakhstan','Southern Kazakhstan'],explain:'Berel is in the Bukhtarma River valley in East Kazakhstan.',trap:'It is often confused with Issyk in Almaty Region.'},
  i22:{skill:'Key Dates',stem:'What year is traditionally accepted as the founding of the Kazakh Khanate?',options:['1465','1511','1428','1731'],explain:'The traditional date is 1465, when Kerei and Janibek established the khanate in Western Zhetysu.',trap:'1731 is associated with the Junior Zhuz accepting Russian suzerainty.'},
  i23:{skill:'Legal Codes',stem:'The legal code “Zheti Zhargy” is associated with:',options:['Tauke Khan','Esim Khan','Hak-Nazar Khan','Ablai Khan'],explain:'“Zheti Zhargy” took shape under Tauke Khan at the turn of the 17th–18th centuries.',trap:'“Esim Khan’s Old Path” is the legal code associated with Esim Khan.'},
  i24:{skill:'Military History',stem:'Who led the forces at the 1643 Battle of Orbulak?',options:['Jangir Khan','Esim Khan','Ablai Khan','Tauekel Khan'],explain:'Jangir Khan’s force stopped a much larger Dzungar army.'},
  i25:{skill:'Path to Independence',stem:'When was the Declaration of State Sovereignty of the Kazakh SSR adopted?',options:['October 25, 1990','December 16, 1991','December 1, 1991','August 30, 1995'],explain:'The Supreme Council adopted the declaration on October 25, 1990.',trap:'August 30, 1995 is the date of the Constitution of Kazakhstan.'},
  i26:{skill:'Statehood',stem:'When was the Constitutional Law “On State Independence of the Republic of Kazakhstan” adopted?',options:['December 16, 1991','October 25, 1990','December 10, 1991','March 2, 1992'],explain:'The law on state independence was adopted on December 16, 1991.'},
  i27:{skill:'Social Movements',stem:'In what year did the December events in Alma-Ata take place?',options:['1986','1979','1991','1989'],explain:'The youth protests took place on December 17–18, 1986.',trap:'1979 refers to the events in Tselinograd.'},
};

const SUBJECT_KZ: Record<SubjectId,string> = { math:'Математика', physics:'Физика', history:'Қазақстан тарихы' };
const SUBJECT_EN: Record<SubjectId,string> = { math:'Mathematics', physics:'Physics', history:'History of Kazakhstan' };

const REGION_KZ: Record<string,string> = {
  'Туркестанская обл.':'Түркістан обл.', 'Жамбылская обл.':'Жамбыл обл.', 'Алматинская обл.':'Алматы обл.',
  'Кызылординская обл.':'Қызылорда обл.', 'Актюбинская обл.':'Ақтөбе обл.', 'Абайская обл.':'Абай обл.',
  'ВКО':'ШҚО', 'СКО':'СҚО', 'Карагандинская обл.':'Қарағанды обл.', 'Костанайская обл.':'Қостанай обл.',
  'Павлодарская обл.':'Павлодар обл.', 'Атырауская обл.':'Атырау обл.', 'ЗКО':'БҚО',
  'Мангистауская обл.':'Маңғыстау обл.', 'Акмолинская обл.':'Ақмола обл.', 'Жетысуская обл.':'Жетісу обл.',
  'Улытау':'Ұлытау', 'г. Астана':'Астана қ.', 'г. Алматы':'Алматы қ.', 'г. Шымкент':'Шымкент қ.',
};
const SCHOOL_KZ: Record<string,string> = {
  'СШ №4, с. Мерке':'№4 ОМ, Меркі ауылы', 'ОШ №12, Аягоз':'№12 ОМ, Аягөз', 'Гимназия №3, Тараз':'№3 гимназия, Тараз',
  'СШ им. Абая, аул Кызылжар':'Абай атындағы ОМ, Қызылжар ауылы', 'СШ №7, Аральск':'№7 ОМ, Арал',
};
const SCHOOL_EN: Record<string,string> = {
  'СШ №4, с. Мерке':'School No. 4, Merke', 'ОШ №12, Аягоз':'School No. 12, Ayagoz', 'Гимназия №3, Тараз':'Gymnasium No. 3, Taraz',
  'СШ им. Абая, аул Кызылжар':'Abai School, Kyzylzhar village', 'СШ №7, Аральск':'School No. 7, Aralsk',
};

const REGION_EN: Record<string,string> = {
  'Туркестанская обл.':'Turkistan Region', 'Жамбылская обл.':'Zhambyl Region', 'Алматинская обл.':'Almaty Region',
  'Кызылординская обл.':'Kyzylorda Region', 'Актюбинская обл.':'Aktobe Region', 'Абайская обл.':'Abai Region',
  'ВКО':'East Kazakhstan Region', 'СКО':'North Kazakhstan Region', 'Карагандинская обл.':'Karaganda Region',
  'Костанайская обл.':'Kostanay Region', 'Павлодарская обл.':'Pavlodar Region', 'Атырауская обл.':'Atyrau Region',
  'ЗКО':'West Kazakhstan Region', 'Мангистауская обл.':'Mangystau Region', 'Акмолинская обл.':'Akmola Region',
  'Жетысуская обл.':'Zhetisu Region', 'Улытау':'Ulytau', 'г. Астана':'Astana', 'г. Алматы':'Almaty', 'г. Шымкент':'Shymkent',
};


const SECTION_KZ: Record<string,string> = {
  'Математическая грамотность': 'Математикалық сауаттылық',
  'Грамотность чтения': 'Оқу сауаттылығы',
  'История Казахстана': 'Қазақстан тарихы',
  'Профильный I': 'Бейіндік I',
  'Профильный II': 'Бейіндік II',
};
const SECTION_EN: Record<string,string> = {
  'Математическая грамотность': 'Mathematical Literacy',
  'Грамотность чтения': 'Reading Literacy',
  'История Казахстана': 'History of Kazakhstan',
  'Профильный I': 'Profile Subject I',
  'Профильный II': 'Profile Subject II',
};

const REASON_KZ: Record<string,string> = { 'Пробел': 'Олқылық', 'Закрепление': 'Бекіту', 'Усложнение': 'Күрделендіру' };
const REASON_EN: Record<string,string> = { 'Пробел': 'Gap', 'Закрепление': 'Reinforcement', 'Усложнение': 'Advanced' };
const CONFIDENCE_KZ: Record<string,string> = { 'высокая': 'жоғары', 'средняя': 'орташа', 'низкая': 'төмен' };
const CONFIDENCE_EN: Record<string,string> = { 'высокая': 'high', 'средняя': 'medium', 'низкая': 'low' };

export function localizeSectionLabel(label: string, lang: Lang) {
  return lang === 'kz' ? SECTION_KZ[label] ?? label : lang === 'en' ? SECTION_EN[label] ?? label : label;
}

export function localizeReason(reason: string, lang: Lang) {
  return lang === 'kz' ? REASON_KZ[reason] ?? reason : lang === 'en' ? REASON_EN[reason] ?? reason : reason;
}

export function localizeConfidence(confidence: string, lang: Lang) {
  return lang === 'kz' ? CONFIDENCE_KZ[confidence] ?? confidence : lang === 'en' ? CONFIDENCE_EN[confidence] ?? confidence : confidence;
}

export function localizeTopic(topic: Topic, lang: Lang): Topic {
  const tr = lang === 'kz' ? TOPIC_KZ[topic.id] : lang === 'en' ? TOPIC_EN[topic.id] : undefined;
  return tr ? { ...topic, ...tr, theory: { ...topic.theory, ...tr.theory } } : topic;
}

export function localizeItem(item: Item, lang: Lang): Item {
  const tr = lang === 'kz' ? ITEM_KZ[item.id] : lang === 'en' ? ITEM_EN[item.id] : undefined;
  return tr ? { ...item, ...tr } : item;
}

export function localizeSubject(subject: { id: SubjectId; title: string }, lang: Lang) {
  return { ...subject, title: lang === 'kz' ? SUBJECT_KZ[subject.id] : lang === 'en' ? SUBJECT_EN[subject.id] : subject.title };
}

export function localizeSchool(school: string, lang: Lang) {
  return lang === 'kz' ? SCHOOL_KZ[school] ?? school : lang === 'en' ? SCHOOL_EN[school] ?? school : school;
}

export function localizeRegion(region: string, lang: Lang) {
  return lang === 'kz' ? REGION_KZ[region] ?? region : lang === 'en' ? REGION_EN[region] ?? region : region;
}
