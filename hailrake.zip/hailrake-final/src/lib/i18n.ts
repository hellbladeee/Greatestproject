export const translations = {
  ru: {
    title: "Hailrake Mentor",
    subtitle: "Академический ИИ-репетитор для подготовки к ЕНТ",
    askPlaceholder: "Задайте вопрос по математике, физике или истории...",
    send: "Спросить",
    context: "Контекст ответа",
    grade: "Класс",
    goal: "Цель",
  },
  kz: {
    title: "Hailrake Mentor",
    subtitle: "ҰБТ-ға дайындыққа арналған академиялық AI-репетитор",
    askPlaceholder: "Математика, физика немесе тарих бойынша сұрақ қойыңыз...",
    send: "Сұрау",
    context: "Жауап мәтіні",
    grade: "Сынып",
    goal: "Мақсат",
  },
  en: {
    title: "Hailrake Mentor",
    subtitle: "Academic AI Tutor for ENT Preparation",
    askPlaceholder: "Ask a question about math, physics, or history...",
    send: "Ask",
    context: "Response Context",
    grade: "Grade",
    goal: "Goal",
  },
};

export type Lang = 'ru' | 'kz' | 'en';