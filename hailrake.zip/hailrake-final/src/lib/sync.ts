import { supabase } from './supabaseClient';
import { forecast, tierOf, type ClassStudent } from './engine';
import type { Profile } from './state';
import type { SubjectId, Topic, Item } from './data';

interface StudentRow {
  id: string;
  class_code: string | null;
  name: string;
  grade: number | null;
  region: string | null;
  school: string | null;
  subjects: SubjectId[] | null;
  goal: string | null;
  target: number | null;
  mastery: Record<string, number> | null;
  attempts_by_topic: Record<string, number> | null;
  correct_count: number | null;
  total_count: number | null;
  xp: number | null;
  login: string | null;
}

// Отправляет снимок текущего прогресса ученика в Supabase. Fire-and-forget —
// не блокирует пользователя и не мешает работе локального движка, если Supabase недоступен.
export function syncStudentProgress(
  profile: Profile,
  mastery: Record<string, number>,
  attemptsByTopic: Record<string, number>,
  correctCount: number,
  totalCount: number,
  xp: number,
  classCode: string
) {
  supabase
    .from('students')
    .upsert({
      id: profile.id,
      class_code: classCode || null,
      name: profile.name,
      grade: profile.grade,
      region: profile.region,
      school: profile.school,
      subjects: profile.subjects,
      goal: profile.goal,
      target: profile.target,
      mastery,
      attempts_by_topic: attemptsByTopic,
      correct_count: correctCount,
      total_count: totalCount,
      xp,
      updated_at: new Date().toISOString(),
    })
    .then(({ error }: { error: { message: string } | null }) => {
      if (error) console.log('⚠️ Не удалось синхронизировать прогресс ученика:', error.message);
    });
}

function rowToClassStudent(row: StudentRow, customTopics: Topic[]): ClassStudent {
  const subjects = row.subjects ?? (['math', 'physics'] as SubjectId[]);
  const mastery = row.mastery ?? {};
  const attempts = row.attempts_by_topic ?? {};
  const f = forecast(subjects, mastery, attempts, customTopics, row.target ?? 110);
  return {
    id: row.id,
    name: row.name,
    grade: row.grade ?? 11,
    region: row.region ?? '—',
    school: row.school ?? '—',
    subjects,
    mastery,
    attempts: row.total_count ?? 0,
    accuracy: row.total_count ? (row.correct_count ?? 0) / row.total_count : 0,
    predicted: f.predicted,
    tier: tierOf(f.predicted),
  };
}

// Загружает реальных учеников этого класса (по короткому коду, не по логину учителя).
export async function fetchClassStudents(classCode: string, customTopics: Topic[]): Promise<ClassStudent[]> {
  const { data, error } = await supabase.from('students').select('*').eq('class_code', classCode);
  if (error || !data) {
    console.log('⚠️ Не удалось загрузить учеников:', error?.message);
    return [];
  }
  return (data as StudentRow[]).map((row) => rowToClassStudent(row, customTopics));
}

// Учитель создаёт аккаунт ученика вручную — логин/пароль задаёт сам.
export async function createStudentAccount(
  classCode: string,
  name: string,
  grade: number,
  login: string,
  password: string
) {
  const id = `stu-${crypto.randomUUID()}`;
  const { error } = await supabase.from('students').insert({
    id,
    class_code: classCode,
    name,
    grade,
    login,
    password,
    mastery: {},
    attempts_by_topic: {},
  });
  if (error) throw new Error(error.message);
  return id;
}

export async function deleteStudentAccount(id: string) {
  const { error } = await supabase.from('students').delete().eq('id', id);
  if (error) throw new Error(error.message);
}

export async function updateStudentName(id: string, name: string, grade: number) {
  const { error } = await supabase.from('students').update({ name, grade }).eq('id', id);
  if (error) throw new Error(error.message);
}

// Вход ученика по логину/паролю, созданным учителем. Возвращает id существующей
// записи в Supabase — важно использовать именно его как profile.id, чтобы дальнейшая
// синхронизация обновляла ТУ ЖЕ строку, а не создавала новую на каждом устройстве.
export async function studentLogin(login: string, password: string) {
  const { data, error } = await supabase
    .rpc('verify_student', { p_login: login.trim(), p_password: password })
    .maybeSingle();
  if (error || !data) return null;
  return data as { id: string; name: string; class_code: string | null };
}

// Темы и задания, которые учитель добавил через конструктор модулей — раньше сохранялись
// только в localStorage браузера учителя и ученики их никогда не видели. Теперь хранятся
// в Supabase по коду класса: учитель пишет, ученик читает при загрузке.
export async function saveClassContent(classCode: string, topics: Topic[], items: Item[]) {
  const { error } = await supabase.rpc('save_class_content', {
    p_class_code: classCode,
    p_topics: topics,
    p_items: items,
  });
  if (error) console.log('⚠️ Не удалось сохранить контент класса:', error.message);
}

export async function fetchClassContent(classCode: string): Promise<{ topics: Topic[]; items: Item[] }> {
  const { data: rawData, error } = await supabase
    .rpc('get_class_content', { p_class_code: classCode })
    .maybeSingle();
  const data = rawData as { custom_topics: Topic[] | null; custom_items: Item[] | null } | null;
  if (error || !data) return { topics: [], items: [] };
  return {
    topics: data.custom_topics ?? [],
    items: data.custom_items ?? [],
  };
}
